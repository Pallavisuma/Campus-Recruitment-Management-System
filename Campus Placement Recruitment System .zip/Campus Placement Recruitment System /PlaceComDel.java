import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import java.awt.Color;

public class PlaceComDel {
	JFrame jf;
	JLabel jl;
	JTextField jt;
	JTextField rs;
	JButton submit;
	public String Result(String name)
	{     String g=null;String s=null;

		try{
			s="DELETE FROM COMPANY WHERE COMP_ID="+"'"+name+"'";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@218.248.07:1521:rdbms","it19737016","vasavi");
			Statement stmt=con.createStatement();
		//	System.out.println(s);
			ResultSet r = null;
		   r =  stmt.executeQuery(s);
			//int x = 1;
			//System.out.println(3);
		 rs.setText("Deleted");
			 
			con.close();
		}
		catch(Exception e)
		
		{  
			rs.setText("Error Occured");
			System.out.println("Error Occured");
		
		
		}
		return s;
	}
	PlaceComDel()
	{
	    jf = new JFrame("Delete Details");
	    jl = new JLabel("Enter the CompanyId:");
	    jl.setForeground(Color.WHITE);
	    jt = new JTextField(50);
	    jt.setForeground(Color.BLUE);
	    submit =new JButton("SUBMIT");
	    submit.setForeground(Color.WHITE);
	    rs = new JTextField(60);
	    jf.getContentPane().add(jl);
	    jf.getContentPane().add(jt);
	    jf.getContentPane().add(submit);
	    jf.getContentPane().add(rs);
	   jl.setBounds(27,133,200,20);
	   jt.setBounds(207,133,200,20);

	    submit.setBounds(160,202,100,20);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(-128,-11, 1000, 1610);
		ImageIcon img =new ImageIcon(this.getClass().getResource("Del-1.png"));
		lblNewLabel .setIcon(img);
		jf.getContentPane().add(lblNewLabel);
	    rs.setBounds(27,290,391,53);
	    jf.setSize(870,1500);
		jf.getContentPane().setLayout(null);
		jf.setVisible(true);
		submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
	//	System.out.println(k);
			
		  Result(jt.getText());
		 
			  
		
		   
						
	}});// jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

	   
	}
		public static void main(String[] args) {
	   new PlaceComDel();
		}
	    
	  
} 
	
	
	





