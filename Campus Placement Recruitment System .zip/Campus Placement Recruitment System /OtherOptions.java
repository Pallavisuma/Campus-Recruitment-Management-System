import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.*;
import javax.swing.*;

public class OtherOptions {
JFrame f;
JMenu  submenu2;
JMenuBar  md;
JMenuItem a1,a2,a3,a4,a5,a6;
private JTextField textField;
private JButton btnNewButton_4;
int i,j;
String qury;
String qury2;
int ka;
private JTextField textField_1;
private JButton btnNewButton_10;
private JLabel lblNewLabel;
public void sert(String query)
{
	String dburl ="jdbc:oracle:thin:@218.248.07:1521:rdbms";
	String us = "it19737016";
	String pas ="vasavi";
	try {
		Connection  conn=DriverManager.getConnection(dburl,us,pas);
		System.out.println("Connected");
		String sql ="INSERT INTO Sailors(sid,sname,rating,age)"
				    +"VALUES('200','ala',3,1.5)";
		Statement s =conn.createStatement();
		ResultSet rows = s.executeQuery(query);
		if(rows.next())
		
		 {String a=rows.getString(1)+"  "+rows.getInt(2);
			textField.setText(a);
			System.out.println(a);
			
		}
		 conn.close();
	} catch (SQLException e) {
		
		e.printStackTrace();
		textField.setText("Error Occured");
	}}
public void srt(String query1,String query2)
{   this.qury=query1;
    this.qury2=query2;
	String dburl ="jdbc:oracle:thin:@218.248.07:1521:rdbms";
	String us = "it19737016";
	String pas ="vasavi";
	try {
		Connection  conn=DriverManager.getConnection(dburl,us,pas);
		System.out.println("Connected");
		String sql ="INSERT INTO Sailors(sid,sname,rating,age)"
				    +"VALUES('200','ala',3,1.5)";
		Statement s =conn.createStatement();
		ResultSet ro = s.executeQuery(qury);
		
	if(ro.next()) {
		 ka=ro.getInt(1);
	
		//System.out.println(ka);
		
	}ro.close();
	ResultSet r02 =s.executeQuery(qury2);
	if(r02.next()) {
		int pa=r02.getInt(1);
		float per = ( (ka*100) /pa);
		 String p= "'"+per+"'";
		textField.setText(p);
	//	System.out.println(per);
		
	}  
	
		 
	}catch(ArithmeticException e) {
		textField.setText("THERE ARE NO STUDENT_DETAILS UNDER THE PATICULAR SECTION");
		
	}
	catch (SQLException e) {
		
		e.printStackTrace();
		textField.setText("Error Occured");
	}}
 public OtherOptions(){
	f = new JFrame("OtherOptions");
	submenu2 = new JMenu("BRANCH_WISE_PLACEMENT PERCENTAGE");
	a1 =new JMenuItem("CSE");
	a2 =new JMenuItem("IT");
	a3 =new JMenuItem("ECE");
	a4 =new JMenuItem("MECHANICAL");
	a5 =new JMenuItem("EEE");
	a6=new JMenuItem("CIVIL");
	
	f.setSize(1000,1000);
	f.getContentPane().setLayout(null);
	
	JButton btnNewButton = new JButton("TOTAL_PlACEMENT_PERCENTAGE");
	btnNewButton.setBounds(667, 73, 296, 29);
	f.getContentPane().add(btnNewButton);
	
	JButton btnNewButton_1 = new JButton("HIGHEST_PACKAGE");
	btnNewButton_1.setBounds(667, 114, 296, 29);
	f.getContentPane().add(btnNewButton_1);
	
	JButton btnNewButton_2 = new JButton("LOWEST_PACKAGE");
	btnNewButton_2.setBounds(667, 155, 296, 29);
	f.getContentPane().add(btnNewButton_2);
	
	JButton btnNewButton_3 = new JButton("TOTAL_MALE_PLACEMENT_PERCENTAGE");
	btnNewButton_3.setBounds(677, 194, 286, 29);
	f.getContentPane().add(btnNewButton_3);
	
	textField = new JTextField();
	textField.setBounds(624, 546, 488, 53);
	f.getContentPane().add(textField);
	textField.setColumns(10);
	btnNewButton.disable();
	
	btnNewButton_4 = new JButton("TOTAL_FEMMALE_PLACEMENT_PERCENTAGE");
	btnNewButton_4.setBounds(667, 239, 322, 29);
	f.getContentPane().add(btnNewButton_4);
	
	JButton btnNewButton_5 = new JButton("CHECK_NTH_HIGHEST_PACKAGE(ENTER BELOW VALUE)");
	btnNewButton_5.setBounds(604, 415, 396, 29);
	f.getContentPane().add(btnNewButton_5);
	
	textField_1 = new JTextField();
	textField_1.setBounds(771, 455, 130, 26);
	f.getContentPane().add(textField_1);
	textField_1.setColumns(10);
	
	
	/*JLabel lblNewLabel = new JLabel("");
	lblNewLabel.setBounds(-250, 6, 1500, 1600);
	ImageIcon img =new ImageIcon(this.getClass().getResource("vp-1.png"));
	lblNewLabel .setIcon(img);
  f.getContentPane().add(lblNewLabel);
	f.getContentPane().add(lblNewLabel);*/
	
	
	JLabel btnNewButton_6 = new JLabel("RECRUITMENT_STAGES_STUDENT_DETAILS");
	btnNewButton_6.setBounds(677, 280, 296, 29);
	f.getContentPane().add(btnNewButton_6);
	
	JLabel lblNewLabel1 = new JLabel("RESULT_BOX");
	lblNewLabel1.setBounds(624, 518, 339, 16);
	f.getContentPane().add(lblNewLabel1);
	
	JButton btnNewButton_7 = new JButton("TYPE_1");
	btnNewButton_7.setBounds(677, 321, 117, 29);
	f.getContentPane().add(btnNewButton_7);
	btnNewButton_7	.addActionListener(new ActionListener(){

		@SuppressWarnings("deprecation")
		@Override
		public void actionPerformed(ActionEvent arg0) {
			new  Model1(1);
		}
		});
	
	JButton btnNewButton_8 = new JButton("TYPE_2");
	btnNewButton_8.setBounds(846, 321, 117, 29);
	f.getContentPane().add(btnNewButton_8);
	
	btnNewButton_10 = new JButton("TYPE_3");
	btnNewButton_10.setBounds(756, 374, 117, 29);
	f.getContentPane().add(btnNewButton_10);
	
	JLabel lblNewLabe = new JLabel("New label");
	lblNewLabe.setBounds(-250, 6, 1500, 1600);
	ImageIcon img =new ImageIcon(this.getClass().getResource("vp-1.png"));
	lblNewLabe .setIcon(img);
	f.getContentPane().add(lblNewLabe);
	btnNewButton_10 .addActionListener(new ActionListener(){

		@SuppressWarnings("deprecation")
		@Override
		public void actionPerformed(ActionEvent arg0) {
			new  Model1(3);
		}
		});
	btnNewButton_8 .addActionListener(new ActionListener(){

		@SuppressWarnings("deprecation")
		@Override
		public void actionPerformed(ActionEvent arg0) {
			new  Model1(2);
		}
		});
/*	JButton btnNewButton_9 = new JButton("TYPE_3");
	btnNewButton_9.setBounds(750, 362, 117, 29);
	btnNewButton_9  .addActionListener(new ActionListener(){

		@SuppressWarnings("deprecation")
		@Override
		public void actionPerformed(ActionEvent arg0) {
			new  Model1(2);
		}
		});*/
	f.setVisible(true);
	f.setSize(1000,700);
	md = new JMenuBar();
	
	
	
	submenu2.add(a1);
	submenu2.add(a2);
	submenu2.add(a3);
	submenu2.add(a4);
	submenu2.add(a5);
    submenu2.add(a6);
    md.add(submenu2);
    f.setJMenuBar(md);
    btnNewButton_3.addActionListener(new ActionListener(){

		@SuppressWarnings("deprecation")
		@Override
		public void actionPerformed(ActionEvent arg0) {
			
			// Vw("CSE");  
			String query1 = "select count(DISTINCT STUDENT_ID) FROM INTERVIEWED_STUDENTS WHERE STUDENT_ID IN(SELECT STUDENT_ID FROM STUDENT WHERE GENDER ='MALE')";
			String query2 = "select count(DISTINCT STUDENT_ID) FROM STUDENT WHERE GENDER ='MALE'";
					srt(query1,query2);
				  
		}
		});
    btnNewButton_4.addActionListener(new ActionListener(){

		@SuppressWarnings("deprecation")
		@Override
		public void actionPerformed(ActionEvent arg0) {
			
			// Vw("CSE");  
			String query1 = "select count(DISTINCT STUDENT_ID) FROM INTERVIEWED_STUDENTS WHERE STUDENT_ID IN(SELECT STUDENT_ID FROM STUDENT WHERE GENDER ='FEMALE')";
			String query2 = "select count(DISTINCT STUDENT_ID) FROM STUDENT WHERE GENDER ='FEMALE'";
					srt(query1,query2);
				  
		}
		});
	//a2.addActionListener(new Action
    a1.addActionListener(new ActionListener(){

		@SuppressWarnings("deprecation")
		@Override
		public void actionPerformed(ActionEvent arg0) {
			
			// Vw("CSE");  
			String query1 = "select count(DISTINCT STUDENT_ID) FROM INTERVIEWED_STUDENTS WHERE STUDENT_ID IN(SELECT STUDENT_ID FROM STUDENT WHERE BRANCH ='CSE')";
			String query2 = "select count(DISTINCT STUDENT_ID) FROM STUDENT WHERE BRANCH ='CSE'";
					srt(query1,query2);
				  
		}
		});
	a2.addActionListener(new ActionListener(){

			@SuppressWarnings("deprecation")
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// Vw("IT");  
				String query1 = "select count(DISTINCT STUDENT_ID) FROM INTERVIEWED_STUDENTS WHERE STUDENT_ID IN(SELECT STUDENT_ID FROM STUDENT WHERE BRANCH ='IT')";
				String query2 = "select count(DISTINCT STUDENT_ID) FROM STUDENT WHERE BRANCH ='IT'";
						srt(query1,query2);
					  
			}
			});a3.addActionListener(new ActionListener(){

				@SuppressWarnings("deprecation")
				@Override
				public void actionPerformed(ActionEvent arg0) {
					// Vw("ECE");  
					String query1 = "select count(DISTINCT STUDENT_ID) FROM INTERVIEWED_STUDENTS WHERE STUDENT_ID IN(SELECT STUDENT_ID FROM STUDENT WHERE BRANCH ='ECE')";
					String query2 = "select count(DISTINCT STUDENT_ID) FROM STUDENT WHERE BRANCH ='ECE'";
							srt(query1,query2);
						  
				}
				});
			a4.addActionListener(new ActionListener(){

					@SuppressWarnings("deprecation")
					@Override
					public void actionPerformed(ActionEvent arg0) {
						// Vw("MECHANICAL");  
						
						String query1 = "select count(DISTINCT STUDENT_ID) FROM INTERVIEWED_STUDENTS WHERE STUDENT_ID IN(SELECT STUDENT_ID FROM STUDENT WHERE BRANCH ='MECHANICAL')";
						String query2 = "select count(DISTINCT STUDENT_ID) FROM STUDENT WHERE BRANCH ='MECHANICAL'";
								srt(query1,query2);
							  
					}
					});
			a5.addActionListener(new ActionListener(){

						@SuppressWarnings("deprecation")
						@Override
						public void actionPerformed(ActionEvent arg0) {
						//	 Vw("EEE");  
							String query1 = "select count(DISTINCT STUDENT_ID) FROM INTERVIEWED_STUDENTS WHERE STUDENT_ID IN(SELECT STUDENT_ID FROM STUDENT WHERE BRANCH ='EEE')";
							String query2 = "select count(DISTINCT STUDENT_ID) FROM STUDENT WHERE BRANCH ='EEE'";
									srt(query1,query2);
								  
						}
						});
			a6.addActionListener(new ActionListener(){

				@SuppressWarnings("deprecation")
				@Override
				public void actionPerformed(ActionEvent arg0) {
					// Vw("CIVIL");  
					String query1 = "select count(DISTINCT STUDENT_ID) FROM INTERVIEWED_STUDENTS WHERE STUDENT_ID IN(SELECT STUDENT_ID FROM STUDENT WHERE BRANCH ='CIVIL')";
					String query2 = "select count(DISTINCT STUDENT_ID) FROM STUDENT WHERE BRANCH ='CIVIL'";
							srt(query1,query2);
						  
				}
				});
			btnNewButton_1.addActionListener(new ActionListener(){

				@SuppressWarnings("deprecation")
				@Override
				public void actionPerformed(ActionEvent arg0) {
					String query = "select * from(select STUDENT_ID, PACKAGE_OFF, dense_rank() over(order by PACKAGE_OFF desc)r from INTERVIEWED_STUDENTS) where r=2";

						
					sert(query);
				}
				});
			btnNewButton_2.addActionListener(new ActionListener(){

				@SuppressWarnings("deprecation")
				@Override
				public void actionPerformed(ActionEvent arg0) {
					String query = "select * from(select STUDENT_ID, PACKAGE_OFF, dense_rank() over(order by PACKAGE_OFF asc)r from INTERVIEWED_STUDENTS) where r=2";

						
					sert(query);
				}
				});
			btnNewButton.addActionListener(new ActionListener(){

				@SuppressWarnings("deprecation")
				@Override
				public void actionPerformed(ActionEvent arg0) {
					String query1 = "select count(DISTINCT STUDENT_ID) FROM INTERVIEWED_STUDENTS";
					String query2 = "select count(DISTINCT STUDENT_ID) FROM STUDENT";
							srt(query1,query2);
				//	System.out.println(i);	
				
				}
				});
			btnNewButton_5.addActionListener(new ActionListener(){

				@SuppressWarnings("deprecation")
				@Override
				public void actionPerformed(ActionEvent arg0) {
					int u =Integer.parseInt(textField_1.getText());
					String query = "select * from(select STUDENT_ID, PACKAGE_OFF, dense_rank() over(order by PACKAGE_OFF desc)r from INTERVIEWED_STUDENTS) where r="+u;

						
					sert(query);
				}
				});
			//f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

}
public static void main(String[] args) {
	   new OtherOptions();
		}
}
