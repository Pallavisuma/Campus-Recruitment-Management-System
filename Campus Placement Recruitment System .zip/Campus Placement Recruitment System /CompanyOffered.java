import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
public class CompanyOffered {



		JTextField  fcom_id,fcom_name,fwebsite,fnu,fdateofVisit,output;
		JLabel com_id,com_name,website,nu,dateofVisit;
		JButton submit;
		JFrame f;
		JMenuBar mb;
		JMenu x,submenu1,submenu2,submenu3,create,delete;
		JMenuItem m1,m2,m3,m4,m5,a1,a2,a3,a4,a5,b1,b2,b3,b4,b5;
	public void Insert(String query)
		{
			String dburl ="jdbc:oracle:thin:@218.248.07:1521:rdbms";
			String us = "it19737016";
			String pas ="vasavi";
			try {
				Connection  conn=DriverManager.getConnection(dburl,us,pas);
				System.out.println("Connected");
				String sql ="INSERT INTO Sailors(sid,sname,rating,age)"
						    +"VALUES('200','ala',3,1.5)";
				Statement s =conn.createStatement();
				int rows = s.executeUpdate(query);
				conn.close();
				if(rows>0) {
				output.setText("Inserted Successfully");
					System.out.println("Inserted Successfully");
					
				}
			} catch (SQLException e) {
				
				e.printStackTrace();
				output.setText("Error Occured");
			}}
		public CompanyOffered(){
			
			f = new JFrame("Companies Visited List");
			mb = new JMenuBar();
			submenu1 = new JMenu("Branch");
			submenu2 = new JMenu("Branch");
			submenu3 = new JMenu("Branch");
			create = new JMenu("New");
			output= new JTextField(30);
			x = new JMenu("Update");
			delete =new JMenu("Delete");
			submit =new JButton("Submit");
			fcom_id =new JTextField(20);
			
			fcom_name=new JTextField(20);
			fwebsite=new JTextField(20);
			fnu=new JTextField(20);
			fdateofVisit=new JTextField(20);
			
			
			com_id=new JLabel("Company ID:");
			com_name=new JLabel("Company Name:");
			website= new JLabel("CompanyWebsite");
			nu=new JLabel("ContactInfo");
			dateofVisit=new JLabel("Date Of Visit");
		//	submit =new JButton("SUBMIT");

			a1 =new JMenuItem("Cse");
			a2 =new JMenuItem("It");
			a3 =new JMenuItem("Ece");
			a4 =new JMenuItem("Mech");
			a5 =new JMenuItem("EEE");
			b1 =new JMenuItem("Cse");
			b2 =new JMenuItem("It");
			b3 =new JMenuItem("Ece");
			b4 =new JMenuItem("Mech");
			b5 =new JMenuItem("EEE");
			m1 =new JMenuItem("Cse");
			m2 =new JMenuItem("It");
			m3 =new JMenuItem("Ece");
			m4 =new JMenuItem("Mech");
			m5 =new JMenuItem("EEE");
			x.add(submenu1);
			create.add(submenu2);
			delete.add(submenu3);
			submenu1.add(m1);
			submenu1.add(m2);
			submenu1.add(m3);
			submenu1.add(m4);
			submenu1.add(m5);
			submenu2.add(a1);
			submenu2.add(a2);
			submenu2.add(a3);
			submenu2.add(a4);
			submenu2.add(a5);
			submenu3.add(b1);
			submenu3.add(b2);
			submenu3.add(b3);
			submenu3.add(b4);
			submenu3.add(b5);
			mb.add(create);
			mb.add(x);
		    mb.add(delete);
		    f.add(com_id);
		    f.add(com_name);
		    f.add(website);
		    f.add(nu);
		    f.add(dateofVisit);
		    f.add(fcom_id);
		    f.add(fcom_name);
		    f.add(fwebsite);
		    f.add(fnu);
		    f.add(fdateofVisit);
		    f.add(output);
            f.add(submit);
			JLabel lblNewLabel = new JLabel("");
			lblNewLabel.setBounds(0,0, 1300, 980);
			ImageIcon img =new ImageIcon(this.getClass().getResource("InsertP-1.png"));
			lblNewLabel .setIcon(img);
			f.getContentPane().add(lblNewLabel);
			
		//	f.add(submit);
			com_id.setBounds(20,50,200,20);
			com_name.setBounds(20,100,200,20);
			website.setBounds(20,150,200,20);
			nu.setBounds(20,200,100,20);
			dateofVisit.setBounds(20,250,100,20);
		
			fcom_id.setBounds(200,50,200,20);
			fcom_name.setBounds(200,100,200,20);
			fwebsite.setBounds(200,150,200,20);
			fnu.setBounds(200,200,200,20);
			fdateofVisit.setBounds(200,250,200,20);
			
			submit.setBounds(150,300,100,30);
			output.setBounds(100,400,200,30);
			f.setSize(800,800);
			f.setJMenuBar(mb);
			
			f.setLayout(null);
			f.setVisible(true);
			
		submit.addActionListener(new ActionListener(){

			@SuppressWarnings("deprecation")
			@Override
			public void actionPerformed(ActionEvent arg0) {
			String a=	fcom_id.getText();
				
			String b=		fcom_name.getText();
			String c=		fwebsite.getText();
			String d=		fnu.getText();
			String e=			fdateofVisit.getText();
					
				String query="INSERT INTO COMPANY VALUES("+"'"+a+"'"+",'"+b+"',"+"'"+c+"',"+"'"+d+"',"+"'"+e+"'"+")";
				Insert(query);
				
				
				
			   
			}
			}); 
		}
		
		
			public static void main(String[] args) {
				new CompanyOffered ();
			}
			
			
			
			
		}
		





