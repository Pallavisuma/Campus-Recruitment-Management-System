import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.*;
public class StudentMainPage {
	JFrame f,f1,f2;
	JButton view,stuv,cmpv;
	TextArea a,stuvtf,cmpvtf;
	JScrollPane scroll;
	String name,v;
	private JButton btnNewButton;
	private JLabel lblNewLabel;
	//TextArea a;
	public void View(String v){  
	  this.v =v;
	 String query1 ="select * from STUDENT WHERE STUDENT_ID='"+v+"'";
	    String query2="select * from INTERVIEWED_STUDENTS WHERE STUDENT_ID='"+v+"'";
		String dburl ="jdbc:oracle:thin:@218.248.07:1521:rdbms";
		String us = "it19737016";
		String pas ="vasavi";
		String kar=null;
		
		String pal=null;
		try {
			Connection  conn=DriverManager.getConnection(dburl,us,pas);
			System.out.println("Connected");
		
			Statement s =conn.createStatement();
			
			 ResultSet rs = s.executeQuery(query1);
			// ResultSet rsy = s.executeQuery(query2);
			
			//;
				//System.out.println(rs);
			if(rs.next()){
				
				   kar="ID: " + rs.getString(1)
		         +"\n"+"NAME: " + rs.getString(2)+"\n"+
		           "GENDER: " + rs.getString(3)+"\n"+
		          "MOBILE_NUMBER: " + rs.getString(4)+"\n"+
		           "BRANCH: " + rs.getString(5)+"\n"+
		        " JOINING_YEAR: "+ rs.getInt(6)+"\n"+
		          "STUDENT_EMAIL " + rs.getString(7)+"\n"+
		         "CGPA: " + rs.getInt(8)+"\n"+
		          "STUD_PASSWORD: " + rs.getString(9)+"\n";
				 //  a.setText (kar);
				   }
			rs.close();
			ResultSet rsy = s.executeQuery(query2);
			if(rsy.next()){
		  pal= "INTERVIEWED_COMPANY: "+ rsy.getString(3)+"\n"+
		          "DESIGNATION_OFFERED: "+ rsy.getString(4)+"\n"+
		          "PACKAGE_OFFERED: "+rsy.getInt(5)+"\n"+
		          "ROUNDS_CLEARED: "+ rsy.getInt(6)+"\n"+
		          "INTERVIEW_MODE(ONLINE/OFFLINE): "+rsy.getString(7);
			 
		     a.setText (kar+pal);
			}
				  
				  
			conn.close();
			
		
		} catch (SQLException e) {
			
			e.printStackTrace();
			a.setText("Error Occured");
		}}
	public void see(int k)
	{   String query2 ="select * from COMPANY";
	    String query1="select * from INTERVIEWED_STUDENTS";
		String dburl ="jdbc:oracle:thin:@218.248.07:1521:rdbms";
		String us = "it19737016";
		String pas ="vasavi";
		String ka=null;
		String tot="";
		String pal=null;
		
		try {
			Connection  conn=DriverManager.getConnection(dburl,us,pas);
			System.out.println("Connected");
		
			Statement s =conn.createStatement();
			
			 ResultSet rsy = s.executeQuery(query1);
			// ResultSet rsy = s.executeQuery(query2);
			
			//;
			 while(rsy.next()){
				  ka=     "STUDENT_ID: "+rsy.getString(1)+"\n"
				  		+ "INTERVIEWED_COMPANY: "+ rsy.getString(3)+"\n"+
				          "DESIGNATION_OFFERED: "+ rsy.getString(4)+"\n"+
				          "PACKAGE_OFFERED: "+rsy.getInt(5)+"\n"+
				          "ROUNDS_CLEARED: "+ rsy.getInt(6)+"\n"+
				          "INTERVIEW_MODE(ONLINE/OFFLINE): "+rsy.getString(7)+"\n\n";
				     
				 tot= tot+ka;
				   }
			  stuvtf.setText (tot);
			rsy.close();
		/*	ResultSet rsy = s.executeQuery(query2);
			if(rsy.next()){
		  pal= "INTERVIEWED_COMPANY: "+ rsy.getString(3)+"\n"+
		          "DESIGNATION_OFFERED: "+ rsy.getString(4)+"\n"+
		          "PACKAGE_OFFERED: "+rsy.getInt(5)+"\n"+
		          "ROUNDS_CLEARED: "+ rsy.getInt(6)+"\n"+
		          "INTERVIEW_MODE(ONLINE/OFFLINE): "+rsy.getString(7);
			 
		     a.setText (kar+pal);
			}*/
				  
				  
			conn.close();
			
		
		} catch (SQLException e) {
			
			e.printStackTrace();
			a.setText("Error Occured");
		}}
	public void se(int k)
	{   String query1 ="select * from COMPANY";
	  //  String query1="select * from INTERVIEWED_STUDENTS";
		String dburl ="jdbc:oracle:thin:@218.248.07:1521:rdbms";
		String us = "it19737016";
		String pas ="vasavi";
		String ka=null;
		String tot="";
	//	String pal=null;
		try {
			Connection  conn=DriverManager.getConnection(dburl,us,pas);
			System.out.println("Connected");
		
			Statement s =conn.createStatement();
			
			 ResultSet rsy = s.executeQuery(query1);
			// ResultSet rsy = s.executeQuery(query2);
			
			//;
			 while(rsy.next()){
				  ka=     "COMPANY_ID: "+rsy.getString(1)+"\n"
				  		+ "COMPANY_NAME: "+ rsy.getString(2)+"\n"+
				          "COMPANY_WEBSITE: "+ rsy.getString(3)+"\n"+
				          "CONTACT_DETAILS"+rsy.getString(4)+"\n"+
				          "DATE_OF_VISIT: "+ rsy.getString(5)+"\n\n";
				        
				     
				 tot= tot+ka;
				   }
			 cmpvtf.setText (tot);
			rsy.close();
		
				  
				  
			conn.close();
			
		
		} catch (SQLException e) {
			
			e.printStackTrace();
			a.setText("Error Occured");
		}}
	StudentMainPage(){}
	StudentMainPage(String name){
		this.name =name;
		  f = new JFrame("STUDENT DETAILS");
		  view= new JButton("CLICK TO VIEW MY DETAILS");
		  cmpv=new JButton("CLICK TO VIEW COMPANY DETAILS");
		  stuv=new JButton("CLICK TO VIEW INTERVIEWD STUDENTS DETAILS");
		 a = new TextArea();
		
		

		  f.getContentPane().add(view);
		  f.getContentPane().add(a);
		  f.getContentPane().add(stuv);
		  f.getContentPane().add(cmpv);
		  view.setBounds(62,637,400,30);
		  stuv.setBounds(62,679,400,30);
		  cmpv.setBounds(62,724,400,30);
		  
		  a.setBounds(521,624,500,158);
		 
		  f.setSize(1000,1000);
		  f.getContentPane().setLayout(null);
		  f.setVisible(true);
		  a.setEditable(false);
		  
		  btnNewButton = new JButton("CLICK HERE OTHER OPTIONS");
		  btnNewButton.setBounds(62, 753, 400, 29);
		  f.getContentPane().add(btnNewButton);
		  
		  lblNewLabel = new JLabel("New label");
		  lblNewLabel.setBounds(-403, 0, 2797, 1007);
		  f.getContentPane().add(lblNewLabel);
		  ImageIcon img =new ImageIcon(this.getClass().getResource("sp-1.png"));
	     lblNewLabel .setIcon(img);

		/*	
		  JLabel lblNewLabel = new JLabel("");
			lblNewLabel.setBounds(-106, -56, 1500, 1543);
					//  f.getContentPane().add(lblNewLabel);
			f.getContentPane().add(lblNewLabel);
			f.setVisible(true);*/
		  btnNewButton.addActionListener(new ActionListener(){

				@SuppressWarnings("deprecation")
				@Override
				public void actionPerformed(ActionEvent arg0) {
				
			
				new	OtherOptions();
					
					
				   
				}
				});
		  view.addActionListener(new ActionListener(){

				@SuppressWarnings("deprecation")
				@Override
				public void actionPerformed(ActionEvent arg0) {
				
			
					View(name);
					
					
					
				   
				}
				});
		  cmpv.addActionListener(new ActionListener(){

				@SuppressWarnings("deprecation")
				@Override
				public void actionPerformed(ActionEvent arg0) {
				
			
				new	StudentMainPage(2);
					
					
					
				   
				}
				});
		  stuv.addActionListener(new ActionListener(){

				@SuppressWarnings("deprecation")
				@Override
				public void actionPerformed(ActionEvent arg0) {
				
			
				new	StudentMainPage(1);
					
					
					
				   
				}
				}); //f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		  }
		StudentMainPage(int k)
		{
			
			switch(k) {
			case 1   :{f1=new JFrame("INTERVIEWED STUDENTS LIST");
			          stuvtf=new TextArea();
			          stuvtf.setBounds(10,10,800,800);
			        
			         // scroll = new JScrollPane(stuvtf); 
			          //this.add(textArea); // get rid of this 
			          f1.getContentPane().add(stuvtf); 
			       //  f1.add(scroll);
			         
			    	  f1.setSize(1000,1000);
					  f1.getContentPane().setLayout(null);
					  f1.setVisible(true);
					  stuvtf.setEditable(false);
					  see(1);
					//  f1.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
					  }break;
			          
			case 2 : {
			       	   f2=new JFrame("COMPANIES LIST");
					 
			           cmpvtf=new TextArea();
			           cmpvtf.setBounds(10,10,800,800);
			           
			       
			               f2.getContentPane().add(cmpvtf);
				 		  
				    	  f2.setSize(1000,1000);
						  f2.getContentPane().setLayout(null);
						  f2.setVisible(true);
						  cmpvtf.setEditable(false);
						  se(1);
						//  f2.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);		 
						  }break;
						
		}
		}
		
	
	public static void main(String[] args) {
		new StudentMainPage("aosdfh");
	}

}
