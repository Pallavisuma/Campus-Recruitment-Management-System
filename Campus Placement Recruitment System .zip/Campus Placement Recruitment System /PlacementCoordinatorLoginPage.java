import java.awt.*;
import java.awt.event.*;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.WindowConstants;

public class PlacementCoordinatorLoginPage extends JFrame{
	JMenuBar mb;
	JMenu x,create,delete,view,Other;
	JMenuItem m1,m2,m3,m4,m5,a1,a2,a3,a4,a5,b1,b2,b3,b4,b5,com1,com2,com3,com4,submenu1,submenu2,submenu4,cli,submenu3;
	JFrame f;
	PlacementCoordinatorLoginPage(){
	f = new JFrame("PlacementCoordinatorLoginPage");
	mb = new JMenuBar();
	submenu1 = new JMenuItem("INTERVIEWD STUDENTS");
	submenu2 = new JMenuItem("INTERVIEWED STUDENTS");
	submenu3 = new JMenuItem("INTERVIEWED STUDENTS");
	submenu4 =new JMenuItem("INTERVIEWED STUDENTS");
	
	com1= new JMenuItem("COMPANIES VISITED ");
	com2= new JMenuItem("COMPANIES VISITED");
	com3= new JMenuItem("COMPANIES VISITED");
	com4 =new JMenuItem("COMPANIES VISITED");
	cli = new JMenuItem("CLICK HERE TO PROCEED");
	
			
	create = new JMenu("INSERT");
	x = new JMenu("MODIFY");
	delete =new JMenu("DELETE");
	view =new JMenu("VIEW");
	Other = new JMenu("VIEW_OTHER_OPTIONS");
	Other.add(cli);
	
	x.add(submenu1);
	create.add(submenu2);
	delete.add(submenu3);
	view.add(submenu4);
	view.add(com4);
	x.add(com1);
	create.add(com2);
	delete.add(com3);
	
	
	
	mb.add(create);
	mb.add(x);
    mb.add(delete);
    mb.add(view);
    mb.add(Other);
    f.setJMenuBar(mb);
	f.setSize(500,500);

	  JLabel lblNewLabel = new JLabel("");
	  lblNewLabel.setBounds(128, -83, 20000, 910);
	  f.getContentPane().add(lblNewLabel);
	  ImageIcon img =new ImageIcon(this.getClass().getResource("pla.png"));
   lblNewLabel .setIcon(img);
	f.getContentPane().setLayout(null);
	f.setVisible(true);
	com2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {

	//	System.out.println(k);
			
			new CompanyOffered ();
		 
			  
		
		   
						
	}});
	submenu2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {

	//	System.out.println(k);
			new StudentInterv();
		 

		   
						
	}});
	  
cli.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {

//	System.out.println(k);
new	OtherOptions();	}});
	
	submenu1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {

	//	System.out.println(k);
			new  PlaceModify();
		 
			  
		
		   
						
	}});
	submenu3.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {

	//	System.out.println(k);
			  new PlaceDelete();
		 
			  
		
		   
						
	}});
	com3.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {

	//	System.out.println(k);
			 new PlaceComDel();
		 
			  
		
		   
						
	}});
	com4.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {

	//	System.out.println(k);
		new	StudentMainPage(2);	}});
			  
			com1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

			//	System.out.println(k);
					new ComModify();
					  
		   
						
	}});
	submenu4.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

			//	System.out.println(k);
					new	StudentMainPage(1);
				 
					  
				
				   
								
			}});
	
	// f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	
	}
	public static void main(String[] args) {
		new PlacementCoordinatorLoginPage();
	}}
