import java.awt.*;

import java.sql.*;
import java.util.Properties;
import java.awt.event.*;
import javax.swing.*;
public class LoginChecker {
	JPanel jp;
	int k;
	JButton jb;
	JLabel lb;
	JLabel un;
	JLabel pwd;
	JTextField untf;
	JTextField pwdtf;
	JFrame jf;
	JTextField result;
	String password;
	String name;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	public String getResult(String name, String password,int k)
	{     String g=null;String s=null;
			switch(k) {
			case 1: s="select STUD_PASSWORD from STUDENT where STUDENT_ID ='"+name+"'";break;
			
		    case 2: s="select PLCR_PWD from PLACEMENT_COORDINATORS where COLLEGE_ID ='"+name+"'";break;
		    case 3: s="select DEPTCR_PASSWORD from DEPARTMENT_COORDINATORS where COLLEGE_ID ='"+name+"'";break;
			}
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@218.248.07:1521:rdbms","it19737016","vasavi");
			Statement stmt=con.createStatement();
			System.out.println(s);
			ResultSet rs = null;
			rs = stmt.executeQuery(s);
			//int x = 1;
			//System.out.println(3);
			if(rs.next())
				g  = rs.getString(1).trim();
			System.out.println(g);
			  if(g.equals(password))
			  {	  result.setText("LoginSuccess");
			  switch(k) {
				case 3: {new SearchBy();new DepartmentLoginPage();};break;
			    case 2:{new SearchBy(); new PlacementCoordinatorLoginPage();};break;
				case 1:{ new SearchBy();new StudentMainPage(name);};break;
				}
			  }
			    
			  else 
				  result.setText("AccessDenied");
			
			con.close();
		}
		catch(Exception e)
		
		{  
			result.setText("Error Occured");
			System.out.println("Error Occured");
		
		
		}
		return s;
	}
LoginChecker(){};

	LoginChecker(int k)
	
	{   this.k=k;
		jp=new JPanel();
		jf=new JFrame("LOGIN PAGE");
		lb=new JLabel("ENTER YOUR LOGIN CREDENTIALS");
		un=new JLabel("USERNAME:");
		pwd=new JLabel("PASSWORD:");
		untf=new JTextField(20);
		pwdtf= new JTextField(20);
		result=new JTextField(30);
		jb=new JButton("SUBMIT");
		lb.setBounds(130,0,400,200);
		//un.setBounds(130,80,200,200);
		untf.setBounds(220,232,200,20);
		//pwd.setBounds(130,110,200,200);
		pwdtf.setBounds(220,355,200,20);
		jb.setBounds(400,450,100,20);
		result.setBounds(400,470,100,20);
		jp.add(lb);
		//jp.add(un);
		jp.add(untf);
		//jp.add(pwd);
		jp.add(pwdtf);
		jp.add(jb);
		jp.add(result);
		jp.setLayout(null);
		jf.getContentPane().add(jp);
		
		lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(-520, 0, 6000, 2000);
		ImageIcon img =new ImageIcon(this.getClass().getResource("Login Image-1 2.png"));
		lblNewLabel_2 .setIcon(img);
		jp.add(lblNewLabel_2);
		
		//lblNewLabel = new JLabel("");
		//ImageIcon img =new ImageIcon(this.getClass().getResource("Login.png"));
		//lblNewLabel .setIcon(img);
		//lblNewLabel.setBounds(6 22, 488, 444);
		//jp.add(lblNewLabel);
		
		
		jf.setSize(600,600);
		jf.setVisible(true);
		jb.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
			System.out.println("k "+ k);
				
			  getResult(untf.getText(),pwdtf.getText(),k);
			 
				  
			
			   
							
		}}); //jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	//	setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}
	public static void main(String[]  args) {
	new LoginChecker(1);
		
	}
}