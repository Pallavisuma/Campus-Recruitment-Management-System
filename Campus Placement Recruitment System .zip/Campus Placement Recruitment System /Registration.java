
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.*;
public class Registration {
	String query;
	JFrame jf;
	JLabel head;
	JLabel clgid;
	JLabel name;
	JLabel mobile,pasw;
	JLabel email;
	JTextField clgidtf,fpasw;
	JTextField nametf;
	JTextField mobiletf;
	JTextField emailtf;
	JTextField res;
	private JButton sub;
	
	private JLabel lblNewLabel_1;
	private JButton btnNewButton;
	public void Insert(String query)
	{
		String dburl ="jdbc:oracle:thin:@218.248.07:1521:rdbms";
		String us = "it19737016";
		String pas ="vasavi";
		try {
			Connection  conn=DriverManager.getConnection(dburl,us,pas);
			System.out.println("Connected");
			String sql ="INSERT INTO Sailors(sid,sname,rating,age)"
					    +"VALUES('200','ala',3,1.5)";
			Statement s =conn.createStatement();
			int rows = s.executeUpdate(query);
			conn.close();
			if(rows>0) {
				res.setText("REGISTERED_SUCCESSFULLY");
				System.out.println("Inserted Successfully");
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}}
		//public static void main(String[
	
	//public static void main(String[
	
	Registration()
	{
		jf=new JFrame("Register");
		head=new JLabel("PLACEMENT COORDINATOR REGISTRATION FORM");
		clgid=new JLabel("COLLEGE ID:");
		name=new JLabel("NAME:");
		mobile=new JLabel("MOBILE NUMBER:");
		email=new JLabel("EMAIL ID:");
		clgidtf=new JTextField(30);
		nametf=new JTextField(30);
		mobiletf=new JTextField(30);
		pasw = new JLabel("PASSWORD");
		emailtf=new JTextField(30);
		fpasw = new JTextField(30);
		res=new JTextField(100);
		sub = new JButton("SUBMIT");
		jf.getContentPane().add(head);
		jf.getContentPane().add(clgid);
		jf.getContentPane().add(name);
		jf.getContentPane().add(mobile);
		jf.getContentPane().add(email);
		jf.getContentPane().add(clgidtf);
		jf.getContentPane().add(nametf);
		jf.getContentPane().add(mobiletf);
		jf.getContentPane().add(emailtf);
		jf.getContentPane().add(res);
		jf.getContentPane().add(pasw);
		jf.getContentPane().add(fpasw);
		head.setBounds(234,6,500,20);
		clgid.setBounds(6,70,100,20);
		clgidtf.setBounds(157,70,173,20);
		name.setBounds(6,102,100,20);
		nametf.setBounds(157,104,173,20);
		mobile.setBounds(6,134,200,20);
		mobiletf.setBounds(157,136,173,20);
		email.setBounds(6,166,124,20);
		pasw.setBounds(6,198,114,20);
		fpasw.setBounds(157,200,173,20);
		emailtf.setBounds(157,168,173,20);
		res.setBounds(6,274,337,30);
		sub.setBounds(106, 232, 100, 30);
		jf.setSize(2000,2000);
		jf.getContentPane().setLayout(null);
		
		btnNewButton = new JButton("SUBMIT");
		btnNewButton.setBackground(Color.ORANGE);
		btnNewButton.setBounds(78, 233, 117, 29);
		jf.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(-106, -56, 1500, 1543);
		ImageIcon img =new ImageIcon(this.getClass().getResource("ReP-1.png"));
		lblNewLabel .setIcon(img);
	//  f.getContentPane().add(lblNewLabel);
		jf.getContentPane().add(lblNewLabel);
		
		/*JButton btnNewButton = new JButton("New button");
		btnNewButton.setBounds(16, 230, 117, 29);
		jf.getContentPane().add(btnNewButton);*/
		jf.setVisible(true);
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String a =	clgidtf.getText();
				String b=	nametf.getText();
				String c=mobiletf.getText();
				String d	=emailtf.getText();
				String e1	=fpasw.getText();
				if(a.length()==4&&c.length()==10)
				{
					JDialog jd=new JDialog(jf,"ERROR");
					JLabel jl= new JLabel("VALID DETAILS");
					jd.add(jl);
					jd.setSize(200,100);
					jd.setVisible(true);
					
					String query="INSERT INTO PLACEMENT_COORDINATORS VALUES("+"'"+a+"'"+",'"+b+"',"+"'"+c+"',"+"'"+d+"',"+"'"+e1+"')";
					Insert(query);	
					
				}
				else
				{
			//String f	=fpasw .getText();
					
					String errorc="";
					if(a.length()!=4)
						errorc=errorc+"INVALID COLLEGE_ID"+"\n";
					if(c.length()!=10)
						errorc=errorc+"INVALID MOBILE NUMBER";
					
					JDialog jd=new JDialog(jf,"ERROR");
					JTextArea kl= new JTextArea();
					kl.setText(errorc);
					
					jd.add(kl);
					jd.setSize(200,100);
					jd.setVisible(true);
					
				}
			}
		});
	
	
		
	
	
	
	}

	public static void main(String[] args)
	{
		new Registration();
	}
}