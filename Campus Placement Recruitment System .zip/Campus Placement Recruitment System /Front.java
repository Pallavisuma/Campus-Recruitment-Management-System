import java.awt.*;


import java.awt.event.*;

import javax.swing.*;
public class Front extends LoginChecker {
	JLabel lb,loginl,regs;
	JPanel pb;
	JButton stu,pla,dep;
	JButton reg;
	JFrame f ; 
	
	Front(){
		f =new JFrame("HomePage");
	   lb =  new JLabel("Campus Recuritment Management System");
	  // pb = new JPanel();
	stu =new JButton("Student");
	dep =new JButton("PlacementCoordinator");
	 pla =new JButton("Department Coordinator");
	   loginl =new JLabel("Login As:");
	   regs =new JLabel("Register:");
		   
	   reg =new JButton("Register");
	   f .setSize(1000 ,800);
	  f.getContentPane().add(lb);
	//  this.add(pb);
	  f.getContentPane().add(stu);
	  f.getContentPane().add(dep);
	  f.getContentPane().add(pla);
	  f.getContentPane().add(loginl);
	  f.getContentPane().add(regs);
	  f.getContentPane().add(reg);
	  lb.setBounds(200,20,500,50);
	  //.setBounds(90,800,800,800);
	  loginl.setBounds(300,100,80,30);
	  regs.setBounds(300,150,80,30);
	  
	  
	  stu.setBounds(360,100,150,30);
	  dep.setBounds(500,100,200,30);
	  pla.setBounds(700,100,200,30);
	  
	  reg.setBounds(360,150,80,30);
	  f.getContentPane().setLayout(null);
	  
	  JLabel lblNewLabel = new JLabel("");
	//  lblNewLabel.setBounds(0, 50, 510, 402);
	  lblNewLabel.setBounds(-520, -80, 6000, 2000);
		ImageIcon img =new ImageIcon(this.getClass().getResource("FrontP-1.png"));
		lblNewLabel .setIcon(img);
	  f.getContentPane().add(lblNewLabel);
	  f.setVisible(true);
	  reg.addActionListener(new ActionListener(){
          
			@SuppressWarnings("deprecation")
			@Override
			public void actionPerformed(ActionEvent arg0) {
			    new Placement();
			}
			});
	  dep.addActionListener(new ActionListener(){
          
			@SuppressWarnings("deprecation")
			@Override
			public void actionPerformed(ActionEvent arg0) {
				//int k=3;
			    new LoginChecker(2);
			}
			});

	 stu.addActionListener(new ActionListener(){
        
			@SuppressWarnings("deprecation")
			@Override
			public void actionPerformed(ActionEvent arg0) {
				//int k=1;
			    new LoginChecker(1);
			 }
			 });

  pla.addActionListener(new ActionListener(){
    
		@SuppressWarnings("deprecation")
		@Override
		public void actionPerformed(ActionEvent arg0) {
			//int k=1;
		    new LoginChecker(3);
		}
		});
  f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
       new Front();
	}
}