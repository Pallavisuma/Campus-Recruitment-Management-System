import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import oracle.net.aso.f;
import java.awt.Color;

public class DepDelete {
	JFrame jf;
	JLabel jl;
	JTextField jt;
	JTextField rs;
	JButton submit;
	public String Result(String name)
	{     String g=null;String s=null;

		try{
			s="DELETE FROM STUDENT WHERE STUDENT_ID="+"'"+name+"'";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@218.248.07:1521:rdbms","it19737016","vasavi");
			Statement stmt=con.createStatement();
		//	System.out.println(s);
			ResultSet r = null;
		   r =  stmt.executeQuery(s);
			//int x = 1;
			//System.out.println(3);
		 rs.setText("Deleted");
			 
			con.close();
		}
		catch(Exception e)
		
		{  
			rs.setText("Error Occured");
			System.out.println("Error Occured");
		
		
		}
		return s;
	}
	DepDelete()
	{
	    jf = new JFrame("Delete Details");
	    jl = new JLabel("Enter the Student User Id:");
	    jl.setForeground(Color.WHITE);
	    jt = new JTextField(50);
	    submit =new JButton("SUBMIT");
	    submit.setForeground(Color.WHITE);
	    rs = new JTextField(60);
	    jf.getContentPane().add(jl);
	    jf.getContentPane().add(jt);
	    jf.getContentPane().add(submit);
	    jf.getContentPane().add(rs);
	   jl.setBounds(20,145,200,28);
	   jt.setBounds(213,153,200,20);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(-128,-11, 1000, 1610);
		ImageIcon img =new ImageIcon(this.getClass().getResource("Del-1.png"));
		lblNewLabel .setIcon(img);
		jf.getContentPane().add(lblNewLabel);
	   

	    submit.setBounds(176,201,100,20);

	    rs.setBounds(96,411,349,51);
		jf.setSize(870,1500);
		jf.getContentPane().setLayout(null);
		jf.setVisible(true);
		submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
	//	System.out.println(k);
			
		  Result(jt.getText());
		 
			  
		
		   
						
	}}); //jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

	}
		public static void main(String[] args) {
		new DepDelete();
		}
	    
	  
	    
	
	
	

}
