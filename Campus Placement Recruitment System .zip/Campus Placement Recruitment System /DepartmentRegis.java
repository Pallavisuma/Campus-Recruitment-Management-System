import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.*;

public class DepartmentRegis {
	String query;
	JLabel name,id,pasw,nu,collid,bran;
	JTextField fname,fid,fpasw,fnu,fcollid,fbran,output;
	JButton submit;
	JFrame f; 
	private JLabel lblNewLabel;
	public void Insert(String query)
	{
		String dburl ="jdbc:oracle:thin:@218.248.07:1521:rdbms";
		String us = "it19737016";
		String pas ="vasavi";
		try {
			Connection  conn=DriverManager.getConnection(dburl,us,pas);
			System.out.println("Connected");
			String sql ="INSERT INTO Sailors(sid,sname,rating,age)"
					    +"VALUES('200','ala',3,1.5)";
			Statement s =conn.createStatement();
			int rows = s.executeUpdate(query);
			conn.close();
			if(rows>0) {
				output.setText("Inserted Successfully");
				System.out.println("Inserted Successfully");
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}}
	DepartmentRegis(){
		f = new JFrame("DepartmentCoordinator Registration Form");
		name =new JLabel("Name:");
		id=new JLabel("User Id:");
		pasw=new JLabel("Password:");
		nu=new JLabel("MobileNumber:");
		collid=new JLabel("CollegeId:");
		bran=new JLabel("Branch:");
		fname =new JTextField(20);
		fid=new JTextField(20);
		fpasw=new JTextField(20);
		fnu=new JTextField(20);
		fcollid=new JTextField(20);
		fbran=new JTextField(20);
		output=new JTextField(40);
		submit =new JButton("Submit");
		f.getContentPane().add(name);
		f.getContentPane().add(id);
		f.getContentPane().add(pasw);
		f.getContentPane().add(nu);
		f.getContentPane().add(collid);
		f.getContentPane().add(bran);
		f.getContentPane().add(fname);
		f.getContentPane().add(fid);
		f.getContentPane().add(fpasw);
		f.getContentPane().add(fnu);
		f.getContentPane().add(fcollid);
		f.getContentPane().add(fbran);
		f.getContentPane().add(submit);
		f.getContentPane().add(output);
		name.setBounds(20,50,200,20);
		id.setBounds(20,100,200,20);
		pasw.setBounds(20,150,200,20);
		nu.setBounds(20,200,100,20);
		collid.setBounds(20,250,100,20);
		bran.setBounds(20,300,200,20);
		
		fname.setBounds(200,50,200,20);
		fid.setBounds(200,100,200,20);
		fpasw.setBounds(200,150,200,20);
		fnu.setBounds(200,200,200,20);
		fcollid.setBounds(200,250,200,20);
		fbran.setBounds(200,300,200,20);
		output.setBounds(20,500,500,100);
		submit.setBounds(150,400,50,20);
		f.setSize(2000,2000);
		f.getContentPane().setLayout(null);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(-106, -56, 1500, 1543);
		ImageIcon img =new ImageIcon(this.getClass().getResource("ReP-1.png"));
		lblNewLabel .setIcon(img);
	//  f.getContentPane().add(lblNewLabel);
		f.getContentPane().add(lblNewLabel);
		f.setVisible(true);
		submit.addActionListener(new ActionListener(){

			@SuppressWarnings("deprecation")
			@Override
			public void actionPerformed(ActionEvent arg0) {
			String a =	fname.getText();
			String b=	fid.getText();
			String c=fpasw.getText();
			String d	=fnu.getText();
			String e	=fcollid.getText();
			String k	=fbran.getText();
		
				if(e.length()==5&& d.length()==(10))
				{
				String query="INSERT INTO DEPARTMENT_COORDINATORS VALUES("+"'"+a+"'"+",'"+b+"',"+"'"+c+"',"+"'"+d+"',"+"'"+e+"',"+"'"+k+"'"+")";
				Insert(query);
				}
				else
				{
					String erc="";
					if(e.length()!=5)
						erc+="INVALID ID\n";
					if(d.length()!=10)
					{
						erc+="INVALID MOBILE NUMBER";
					}
					JDialog kb= new JDialog(f,"ERROR");
					JTextArea ja= new JTextArea();
					ja.setText(erc);
					kb.add(ja);
					kb.setVisible(true);
					kb.setSize(300,300);
					
					
					
							
				}
				
				
			   
			}
			}); //f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		
		
	}
	public static void main(String[] args) {
		new DepartmentRegis();
	}
	

}
