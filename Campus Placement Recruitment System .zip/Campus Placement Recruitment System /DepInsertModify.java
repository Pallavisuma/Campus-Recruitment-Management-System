import java.awt.event.ActionEvent;
import java.util.regex.Matcher;


import java.util.regex.Pattern;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.JTextArea;

//import com.sun.org.apache.xerces.internal.impl.xs.identity.Selector.Matcher;

public class DepInsertModify {
	JMenuBar mb;
	JButton submit,modify,del,insert;
	JMenu x,submenu1,submenu2,submenu3,create,delete;
	JMenuItem m1,m2,m3,m4,m5,a1,a2,a3,a4,a5,b1,b2,b3,b4,b5;
	JFrame f;
	JLabel name,id,gender,phnum,branch,email,cgpa,yearpass,password;
	JTextField na,i,num,gen,bran,ema,gpa,year,output,pasw,gent;
	String stu_name,stu_id,stu_gen,stu_num,stu_bran,stu_email,stu_cgpa,stu_pasw;
	String stu_yearpass;
	private JLabel lblNewLabel_1;
	private JTextField textField;
	
	public boolean checkName(String s)
	{
		if(s.length()==12)
			return true;
		else
			return false;
	}
	public  boolean checkMobile(String m)
	{
		System.out.println("******"+m.length());
		boolean b=true;
		if(m.length()==10)
			b= true;
		else
			b=false;
		return b;
	}
	public boolean checkGender(String g)
	{
		System.out.println("******"+g);
		boolean ret=true;
		if(g.equals("MALE"))
			ret=true;
		else if(g.equals("FEMALE"))
			ret=true;
		else
			ret=false;
		return ret;
			
	}
	public static boolean checkBranch(String b)
	{
		System.out.println("******"+b);
		boolean ret=true;
		if(b.equals("IT"))
			ret=true;
		else if(b.equals("CSE"))
			ret=true;
		else if(b.equals("EEE"))
			ret=true;
		else if(b.equals("ECE"))
			ret=true;
		else if(b.equals("MECHANICAL"))
			ret=true;
		else if(b.equals("CIVIL"))
			ret=true;
		else
			ret=false;
		return ret;
			
	}

	public static boolean checkYear(String m)
	{
		System.out.println("******"+m.length());
		boolean ret=true;
		if(m.length()==4)
			ret= true;
		else
			ret= false;
		return ret;
	}
	
	
	
	public String Res(String stu_id,String stu_name,String stu_gen,String stu_num,String stu_bran,String stu_yearpass ,String stu_email,String stu_cgpa ,String stu_pasw)
	{    
	this.stu_name=stu_name;
    this.stu_id=stu_id;
    this.stu_gen=stu_gen;
    this.stu_num=stu_num;
    this.stu_bran=stu_bran;
    this.stu_email=stu_email;
    this.stu_cgpa=stu_cgpa;
    this. stu_yearpass = stu_yearpass ;
    this.stu_pasw=stu_pasw; 
  
		String g=null;String s=null;

		try{	
			s ="INSERT INTO  STUDENT  VALUES('"+stu_id+"',"+"'"+stu_name+"',"+"'"+stu_gen+"',"+"'"+stu_num+"',"+"'"+stu_bran+"',"+"'"+stu_yearpass+"',"+"'"+stu_email+"',"+"'"+stu_cgpa+"',"+"'"
					+stu_pasw+"')";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@218.248.07:1521:rdbms","it19737016","vasavi");
			Statement stmt=con.createStatement();
		//	System.out.println(s);
			ResultSet r = null;
		
		   r =  stmt.executeQuery(s);
			
			//int x = 1;
			System.out.println(3);
		 output.setText("Data Inserted");
			 
			con.close();
		}
		catch(Exception e)
		
		{  	e.printStackTrace();
			output.setText("Error Occured");
			System.out.println("Error Occured");
		
		
		}
		return s;
	}
	public DepInsertModify(){
		f = new JFrame("Form");
		mb = new JMenuBar();
		submenu1 = new JMenu("Branch");
		submenu2 = new JMenu("Branch");
		submenu3 = new JMenu("Branch");
		create = new JMenu("New");
		x = new JMenu("Update");
		delete =new JMenu("Delete");
		name = new JLabel("Student ID:");
		id = new JLabel("Student Name:");
		gender = new JLabel("Student Gender:");
		phnum= new JLabel("Student MobileNumber:");
		branch = new JLabel("Student Branch:");
		cgpa = new JLabel("Student CGPA:");
		yearpass= new JLabel("Student Year:");
		password =new JLabel("Student Password:");
		email=new JLabel("EMAIL ID");
		submit =new JButton("SUBMIT");
		insert=new JButton("INSERT");
		modify=new JButton("MODIFY");
		del=new JButton("DELETE");
		pasw=new JTextField(20);
		na = new JTextField(20);
		i = new JTextField(20);
		gen= new JTextField(20);
		num = new JTextField(20);
		bran= new JTextField(20);
		ema = new JTextField(20);
		gpa= new JTextField(20);
		year = new JTextField(20);
		output =new JTextField(50);
		
	
	
		
		
		
		a1 =new JMenuItem("Cse");
		a2 =new JMenuItem("It");
		a3 =new JMenuItem("Ece");
		a4 =new JMenuItem("Mech");
		a5 =new JMenuItem("EEE");
		b1 =new JMenuItem("Cse");
		b2 =new JMenuItem("It");
		b3 =new JMenuItem("Ece");
		b4 =new JMenuItem("Mech");
		b5 =new JMenuItem("EEE");
		m1 =new JMenuItem("Cse");
		m2 =new JMenuItem("It");
		m3 =new JMenuItem("Ece");
		m4 =new JMenuItem("Mech");
		m5 =new JMenuItem("EEE");
		f.getContentPane().add(password);
		f.getContentPane().add(pasw);
		f.getContentPane().add(output);
		f.getContentPane().add(name);
		f.getContentPane().add(id);
		f.getContentPane().add(gender);
		f.getContentPane().add(phnum);
		f.getContentPane().add(branch);
		f.getContentPane().add(yearpass);
		f.getContentPane().add(cgpa);
		f.getContentPane().add(na);
		f.getContentPane().add(i);
		f.getContentPane().add(gen);
		f.getContentPane().add(num);
		f.getContentPane().add(bran);
		f.getContentPane().add(ema);
		f.getContentPane().add(gpa);
		//f.add(gen);
		f.getContentPane().add(year);
		f.getContentPane().add(pasw);
		f.getContentPane().add(email);
		x.add(submenu1);
		f.getContentPane().add(submit);
		
		create.add(submenu2);
		delete.add(submenu3);
		submenu1.add(m1);
		submenu1.add(m2);
		submenu1.add(m3);
		submenu1.add(m4);
		submenu1.add(m5);
		submenu2.add(a1);
		submenu2.add(a2);
		submenu2.add(a3);
		submenu2.add(a4);
		submenu2.add(a5);
		submenu3.add(b1);
		submenu3.add(b2);
		submenu3.add(b3);
		submenu3.add(b4);
		submenu3.add(b5);
		mb.add(create);
		mb.add(x);
	    mb.add(delete);
	    name.setBounds(20,50,200,20);
		id.setBounds(20,100,200,20);
		phnum.setBounds(20,150,200,20);
		gender.setBounds(20,200,200,20);
		branch.setBounds(20,250,100,20);
		yearpass.setBounds(20,300,100,20);
		cgpa.setBounds(20,350,100,20);
		password.setBounds(20,400,200,20);
		na.setBounds(200,50,200,20);
		i.setBounds(200,100,200,20);
		num.setBounds(200,150,200,20);
		gen.setBounds(200,200,200,20);
		bran.setBounds(200,250,200,20);
		year.setBounds(200,300,200,20);
		gpa.setBounds(200,350,200,20);
		pasw.setBounds(200,400,200,20);
		submit.setBounds(150,500,50,20);
		output.setBounds(20,600,500,100);
		email.setBounds(20,450,100,20);
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(0,0, 1300, 980);
		ImageIcon img =new ImageIcon(this.getClass().getResource("InsertP-1.png"));
		lblNewLabel .setIcon(img);
		f.getContentPane().add(lblNewLabel);
		//f.setVisible(true);
	
		f.setJMenuBar(mb);
		f.setSize(1000,1000);
		f.getContentPane().setLayout(null);
		
		lblNewLabel_1 = new JLabel("Student_Email");
		lblNewLabel_1.setBounds(20, 449, 117, 16);
		f.getContentPane().add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(210, 432, 190, 26);
		f.getContentPane().add(textField);
		textField.setColumns(10);
		f.setVisible(true);
		
	    
			submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			  String  a= na.getText();
			  String 	b = i.getText();
			  String 	c =gen.getText();
			  String 	d= num.getText();
			  String 	el=bran.getText();
				 String 	fl= textField.getText();
				 String 	g= gpa.getText();
				String h=year.getText();
				 String 	il =pasw.getText();
		//System.out.println(a+b+c+d+el+fl+g+h+il)	;	
		// Res(a,b,c,d,el,h,fl,g,il);
		//	System.out.println(k);
				 String errc="";
		System.out.println(a);
		System.out.println(b);
		if(checkName(a)&&checkMobile(d)&&checkGender(c)&&checkBranch(el)&&(checkYear(h)))
		{
			JDialog jc =new JDialog(f,"DETAILS ARE VALID");
			JLabel vl= new JLabel("ALL ARE VALID");
			jc.add(vl);
			jc.setSize(300,200);
			jc.setVisible(true);
		
			
			Res(a,b,c,d,el,h,fl,g,il);
		}
		else
		{
				 if(checkName(a))
					 System.out.println(a+ " id is valid");
				 else
					 errc=errc+" "+a+" id is not valid\n"+"\n";

				 if(checkMobile(d))
					 System.out.println(d+ " mobile numbser is valid\n");
				 else
					 errc=errc+" "+d+" mobile number  is not valid\n"+"\n";
				
				 if(checkGender(c))
					 System.out.println(c+" gender is valid");
				 else
					 errc=errc+" "+ c+ " gender  is not valid\n"+"\n";
				 if(checkBranch(el))
					 System.out.println(el+" branch is valid");
				 else
					 errc=errc+" "+el +" branch is not valid\n"+"\n";
				 if(checkYear(h))
					 System.out.println(h+" year is valid");
				 else
					 errc=errc+" "+h +" year  is not valid\n"+"\n";
				 JDialog dj= new JDialog(f,"ERROR");
				 JTextArea l= new JTextArea();
				 l.setText(errc);
				 
				 dj.add(l);
				 dj.setSize(300,200);
				 //dj.setLayout(null);
				 dj.setVisible(true);
				 
			 
		}		  
			
			   
							
		}}); //f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
			
} public static void main(String[] args) {
	new DepInsertModify();
}
	
}