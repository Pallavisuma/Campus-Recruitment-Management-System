import java.awt.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Placement extends JFrame  {
	
	JPanel p;
	JButton b;
	JButton a;
	Placement(){
	
	
	
	b= new JButton("Palcement Coordinator Registration");
	a= new JButton("Department Coordinator Registration ");
	p= new JPanel();
	this.add(p);
	p.add(b);
	p.add(a);

	this.setSize(300,300);
	p.setBounds(460,300,500,500);
 	b.setBounds(90,120,50,50);
	a.setBounds(200,120,50,50);
 	
	
	this.setVisible(true);

	a.addActionListener(new ActionListener(){

		@SuppressWarnings("deprecation")
		@Override
		public void actionPerformed(ActionEvent arg0) {
		    new DepartmentRegis();
		}
		});
	
	
	
	b.addActionListener(new ActionListener(){

		@SuppressWarnings("deprecation")
		@Override
		public void actionPerformed(ActionEvent arg0) {
		    new Registration();
		}
		});
	// this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		
	}
	
	
	//setDefaultCloseOperation(EXIT_ON_CLOSE);
	/*
	public static void main(String[] args) {
		// TODO Auto-generated method stub
       new Placement();
	}*/
	

}