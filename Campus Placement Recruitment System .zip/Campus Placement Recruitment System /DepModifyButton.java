import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.*;
import java.awt.Color;

public class DepModifyButton {
JFrame f ;
JButton stu_name,stu_id,stu_gen,stu_num,stu_bran,stu_email,stu_cgpa,stu_yearpass,stu_pasw,submit;
JLabel op,sid,val;
JTextField  fsid,fval,res;
String username ,value,column;
public void UpdateRec(String username,String value,String column) {
	this.username = username;
	this.value=value;
	this.column=column;
	String sql="Update STUDENT set "+column+"='"+value+"'"+"WHERE STUDENT_ID="+"'"+username+"'" ;
	String dburl ="jdbc:oracle:thin:@218.248.07:1521:rdbms";
	String us = "it19737016";
	String pas ="vasavi";
	try {
		Connection  conn=DriverManager.getConnection(dburl,us,pas);
		System.out.println("Connected");
		Statement s =conn.createStatement();
		int rows = s.executeUpdate(sql);
		if(rows>0) {
		res.setText("UPDATED SUCCESSFULLY");
			System.out.println("Inserted Successfully");
			conn.close();
			
		}
	} catch (SQLException e) {
		e.printStackTrace();
		
		res.setText("Error Occured" );
		System.out.println("Error occured");
	}}
		


public DepModifyButton(){
	f = new JFrame("Update Options");
	op = new JLabel("<<<<<SELECT THE OPTIONS TO BE UPDATED AFTER ENTERING DATA>>>>");
	op.setForeground(Color.WHITE);
	sid =new JLabel("ENTER STUDENT ID(TO MODIFY):");
	sid.setForeground(Color.WHITE);
	val = new JLabel("ENTER VALUE TO BE SET:");
	val.setForeground(Color.WHITE);
	fsid = new JTextField(40);
	fval = new JTextField(40);
	submit= new JButton("SUBMIT");
	res=new JTextField(40);
	stu_name =new JButton("STUDENT NAME");
	stu_id  =new JButton("STUDENT ID");
	stu_gen =new JButton("STUDENT GENDER");
	stu_num =new JButton("STUDENT NUMBER");
	stu_bran =new JButton("STUDENT BRANCH");
	stu_email =new JButton("STUDENT EMAIL");
    stu_cgpa =new JButton("STUDENT CGPA");
    stu_yearpass =new JButton("STUDENT YEARPASSOUT");
    stu_pasw =new JButton("STUDENT PASSWORD");
	f.getContentPane().add(stu_name);
	f.getContentPane().add(stu_id);
    f.getContentPane().add(stu_gen);
    f.getContentPane().add(stu_num);
    f.getContentPane().add(stu_bran);
    f.getContentPane().add(stu_email);
    f.getContentPane().add(stu_cgpa);
    f.getContentPane().add(stu_yearpass);
    f.getContentPane().add(stu_pasw);
    f.getContentPane().add(op);
    f.getContentPane().add(sid);
    f.getContentPane().add(fsid);
    f.getContentPane().add(val);
    f.getContentPane().add(fval);
    f.getContentPane().add(submit);
    f.getContentPane().add(res);
    op.setBounds(-11,6,500,20);
    submit.setBounds(382,390,150,20);
    sid.setBounds(622,69,317,20);
    val.setBounds(627,150,300,20);
    fval.setBounds(610,182,300,20);
    fsid.setBounds(610,101,300,20);
    stu_name .setBounds(60,38,236,20);
    stu_id.setBounds(60,70,236,20);
    stu_gen.setBounds(60,102,236,20);
    stu_num.setBounds(60,134,236,20);
    stu_bran.setBounds(60,163,236,20);
    stu_email.setBounds(60,195,236,20);
    stu_cgpa.setBounds(60,221,236,20);
    stu_yearpass.setBounds(60,253,238,20);
    stu_pasw.setBounds(58,278,244,20);
    res.setBounds(235,422,500,26);
    JLabel lblNewLabel = new JLabel("");
	lblNewLabel.setBounds(-335, 0, 1471, 1490);
	ImageIcon img =new ImageIcon(this.getClass().getResource("Mdp-1.png"));
	lblNewLabel .setIcon(img);
	f.getContentPane().add(lblNewLabel);
	
    f.setSize(1000,1000);
	f.getContentPane().setLayout(null);
	f.setVisible(true);
	stu_name.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			String g=fsid.getText();
			String s=fval.getText();
			String n="STUDENT_NAME";
			UpdateRec(g,s,n);
		}
	});
		
	stu_id.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			String g=fsid.getText();
			String s=fval.getText();
			String n="STUDENT_ID";
			UpdateRec(g,s,n);
		}
	});
		
	stu_gen.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			String g=fsid.getText();
			String s=fval.getText();
			String n="GENDER";
			UpdateRec(g,s,n);
		}
	});
		
	  stu_num.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			String g=fsid.getText();
			String s=fval.getText();
			String n="MOBILE_NUMBER";
			UpdateRec(g,s,n);
		}
	});
		
	  stu_email.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			String g=fsid.getText();
			String s=fval.getText();
			String n="STUDENT_EMAILID";
			UpdateRec(g,s,n);
		}
	});
		
	  stu_cgpa.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			String g=fsid.getText();
			String s=fval.getText();
			String n="CGPA";
			UpdateRec(g,s,n);
		}
	});
	  stu_yearpass.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			String g=fsid.getText();
			String s=fval.getText();
			String n="JOINING_YEAR";
			UpdateRec(g,s,n);
		}
	});
	  stu_pasw.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			String g=fsid.getText();
			String s=fval.getText();
			String n="STUD_PASSWORD";
			UpdateRec(g,s,n);
		}
	});
	  stu_bran.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			String g=fsid.getText();
			String s=fval.getText();
			String n="BRANCH";
			UpdateRec(g,s,n);
		}
	});// f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		
    
}
public static void main(String[] args) {
	new DepModifyButton();
}

}
