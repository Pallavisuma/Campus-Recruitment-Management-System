import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class SearchBy {

	JFrame f;
	JLabel usid;
	JTextField tf;
	JTextArea ta;
	JButton sub;
	String r="";
	String k="";

	public void getResult(String name)
	{
		boolean s=false;
		boolean m=false;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@218.248.07:1521:rdbms","it19737016","vasavi");
			Statement stmt=con.createStatement();
			System.out.println("okay");
			String query="select * from STUDENT where STUDENT_ID="+"'"+name+"'";
			ResultSet rs=stmt.executeQuery(query);
			System.out.println("executed");
			while(rs.next())
			{
				s=true;
				r+="STUDENT_ID: "+rs.getString(1)+"\n"+"STUDENT NAME: "+rs.getString(2)+"\n"+"GENDER: "+rs.getString(3)+"\n"+"BRANCH: "+rs.getString(5)+"\n"
			+"YEAR: "+rs.getString(4)+"\n"+"CGPA: "+rs.getString(7);
			}
			if(s)
			{
				
				{
				String query1="select * from INTERVIEWED_STUDENTS where STUDENT_ID="+"'"+name+"'";
				ResultSet rsi=stmt.executeQuery(query1);
				while(rsi.next())
				{
					m=true;
					k="\nCOMPANY_ID: "+rsi.getString(2)+"\n"+"COMPANY_NAME: "+rsi.getString(3)+"\n"+"DESIGNATION: "+rsi.getString(4)+"\n"+"PACKAGE OFFERED: "+rsi.getString(5);
				}
				//ta.setText(r+k);
				if(m)
				{
						ta.setText(r+k);
				}
				else
				{
					ta.setText("STUDENT HASN'T ATTENDED INTERVIEW");
				}
				rsi.close();}
				
				
				
			}
			else
			{
				System.out.println("not");
				ta.setText("NOT FOUND");
			}
			
			rs.close();
			//System.out.println(r);
			//ta.setText(r);
			/*if(s)
			{
			String query1="select * from INTERVIEWED_STUDENTS where STUDENT_ID="+"'"+name+"'";
			ResultSet rsi=stmt.executeQuery(query1);
			while(rsi.next())
			{
				m=true;
				k="\nCOMPANY_ID"+"\t\t\t"+rsi.getString(2)+"\n"+"COMPANY_NAME"+"\t\t"+rsi.getString(3)+"\n"+"DESIGNATION"+"\t\t\t"+rsi.getString(4)+"\n"+"PACKAGE OFFERED"+"\t\t"+rsi.getString(5);
			}
			//ta.setText(r+k);
			if(m)
			{
					ta.setText(r+k);
			}
			else
			{
				ta.setText("STUDENT HASN'T ATTENDED INTERVIEW");
			}*/
			
			
			
			
			
			
			//ResultSet rs=stmt.executeQuery(query);
			con.close();
			
		}
		catch(Exception e)
		{
			//System.out.println("Error");
			 //s=false;
			e.printStackTrace();
		}
	
	}
	public void getResult2(String name)
	{
		boolean s=false;
		//boolean m=false;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@218.248.07:1521:rdbms","it19737016","vasavi");
			Statement stmt=con.createStatement();
			System.out.println("okay");
			String query="SELECT * FROM DEPARTMENT_COORDINATORS where COLLEGE_ID="+"'"+name+"'";
			ResultSet rs=stmt.executeQuery(query);
			
			while(rs.next())
			{
				s=true;
				r="DEPARTMENT_COORDINATOR DETAILS\n"+"NAME:"+rs.getString(1)+"\n"+
						"DEPARTMENT_ID: "+rs.getString(2)+"\n"+
						 "MOBILE NUMBER: "+rs.getString(4)+"\n"+
						"COLLEGE_ID: "+rs.getString(5)+"\n"+
						"DEPARTMENT: "+rs.getString(6)+"\n";
				
			}
			if(s)
			{
				ta.setText(r);
			}
			else
			{
				ta.setText("NOT FOUND");
			}
			con.close();
			
			
		}
		catch(Exception e)
		{
			System.out.println("Error");
			 //s=false;
			e.printStackTrace();
		}
	
	}
	public void getResult3(String name)
	{
		boolean s=false;
		//boolean m=false;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@218.248.07:1521:rdbms","it19737016","vasavi");
			Statement stmt=con.createStatement();
			System.out.println("okay");
			String query="select * from PLACEMENT_COORDINATORS where COLLEGE_ID="+"'"+name+"'";
			ResultSet rs=stmt.executeQuery(query);
			System.out.println("executed");
			while(rs.next())
			{
				s=true;
				r="PLACEMENT_COORDINATOR DETAILS\n"+"NAME:"+rs.getString(1)+"\n"+
						"COLLEGE_ID: "+rs.getString(2)+"\n"+
						 "MOBILE NUMBER: "+rs.getString(3)+"\n"+
						"EMAIL: "+rs.getString(4)+"\n";
				
			}
			if(s)
			{
				ta.setText(r);
			}
			else
			{
				ta.setText("NOT FOUND");
			}
			
			
		}
		catch(Exception e)
		{
			//System.out.println("Error");
			 //s=false;
			e.printStackTrace();
		}
	
	}



	SearchBy()
	{
		f=new JFrame("SEARCH BY PAGE");
		usid=new JLabel("ENTER USERID");
		usid.setForeground(UIManager.getColor("EditorPane.selectionBackground"));
		usid.setBackground(UIManager.getColor("EditorPane.selectionBackground"));
		ta= new JTextArea();
		sub= new JButton("SUBMIT");
		sub.setForeground(UIManager.getColor("ComboBox.selectionBackground"));
		tf=new JTextField(30);
		f.getContentPane().add(usid);
		f.getContentPane().add(ta);
		f.getContentPane().add(sub);
		f.getContentPane().add(tf);
		usid.setBounds(978,243,100,20);
		tf.setBounds(753,330,200,20);
		
		sub.setBounds(748,608,100,20);
		ta.setBounds(6,6,278,713);
		JLabel lblNewLabel = new JLabel("");
		  lblNewLabel.setBounds(-65, -34, 1773, 1761);
		  f.getContentPane().add(lblNewLabel);
		  ImageIcon img =new ImageIcon(this.getClass().getResource("sear-1.png"));
	   lblNewLabel .setIcon(img);
		f.getContentPane().setLayout(null);
	f.setVisible(true);
	//	f.setVisible(true);
	f.setSize(1500,1500);
		f.getContentPane().setLayout(null);
		sub.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				System.out.println("submitted");
				System.out.println(tf.getText());
				String check=tf.getText();
				int len=check.length();
				if(len==15)
					getResult(check);
				else if(len==5)
					{
					System.out.println("depart");
					getResult2(check);
					}
				else if(len==4)
					getResult3(check);
				else
					ta.setText("INVALID USER_ID");
				//ta.setText("FOUND");
			}
		});
		
		
	}
	public static void main(String[] args)
	{
		new SearchBy();
	}
	
}