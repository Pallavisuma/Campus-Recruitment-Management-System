	import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;   
public class Model1 {
  String x,y,z,x2,y2,z2,W;
	int i;
int k;
	String dburl ="jdbc:oracle:thin:@218.248.07:1521:rdbms";
	String us = "it19737016";
	String pas ="vasavi";
	    JFrame f,f2,f3;    
	    Model1(int k){    
	   this.k =k;
	    switch(k) {
	  
	    case 1 : {  f=new JFrame(); 
	       Object[] [] rowData= {};
	    
       Object columnNames[]={"STUDENT_ID","COMP_ID","APT","TECH","HR"};         
	    	    DefaultTableModel listTableModel;
	                 listTableModel  = new DefaultTableModel(rowData,columnNames);
	                /* for(i=0;i<3;i++) {

	                    // String rowString = "Quiz #" + i;
	                     listTableModel.addRow(new Object[] { rowString, "ICON", "ICON" });
	                 }*/
	                 String query1 ="select * from MODEL1";
	                		   
	                			String kar=null;
	                			
	                			String pal=null;
	                			try {
	                				Connection  conn=DriverManager.getConnection(dburl,us,pas);
	                				System.out.println("Connected");
	                			
	                				Statement s =conn.createStatement();
	                				
	                				 ResultSet rs = s.executeQuery(query1);
	                						while(rs.next()){
	                						String a=	rs.getString(1);
	                						String b=rs.getString(2);
	                					  
	                						 int c =rs.getInt(3);
	                						 if(c==1) {
	                						 x  = "QUALIFIED";}
	                						 else { x="NOT_QUALIFIED";}
	                						 int d =rs.getInt(4);
	                						 if(d==1) {
	 	                						y  = "QUALIFIED";}
	 	                						 else { y="NOT_QUALIFIED";}
	                						 int f =rs.getInt(5);
	                						 if(f==1) {
	 	                						 z = "QUALIFIED";}
	 	                						 else { z="NOT_QUALIFIED";}
	                						 
	                					 listTableModel.addRow(new Object[] { rs.getString(1),rs.getString(2),x,y,z });
	                					   }
	                				rs.close();
	                			
	                					  
	                					  
	                				conn.close();
	                				
	                			
	                			} catch (SQLException e) {
	                				
	                				e.printStackTrace();
	                			}
	                 JTable listTable;
	                 listTable = new JTable(listTableModel);
	                
	                 listTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
	                 listTable.setCellEditor(null);   
	                 f.add(new JScrollPane(listTable));
		               f.setVisible(true);
		                f.pack();
		     
	                 listTable.setBounds(37, 143, 400, 183);
	                 } break;
	    case 2:{   
	              f2=new JFrame(); 
	    
	    	  Object[] [] rowData2= {};
	    
	                Object columnNames2[]={"STUDENT_ID","COMP_ID","APT","TECH","PANEL","HR"};         
	         	    	    DefaultTableModel listTableModel2;
	         	                 listTableModel2  = new DefaultTableModel(rowData2,columnNames2);
	         	                /* for(i=0;i<3;i++) {

	         	                    // String rowString = "Quiz #" + i;
	         	                     listTableModel.addRow(new Object[] { rowString, "ICON", "ICON" });
	         	                 }*/
	         	                 String query2 ="select * from MODEL2";
	         	                		   
	         	                			
	         	                			
	         	                			try {
	         	                				Connection  conn=DriverManager.getConnection(dburl,us,pas);
	         	                				System.out.println("Connected");
	         	                			
	         	                				Statement s =conn.createStatement();
	         	                				
	         	                				 ResultSet rs = s.executeQuery(query2);
	         	                						while(rs.next()){
	         	                						String a2=	rs.getString(1);
	         	                						String b2=rs.getString(2);
	         	                					  
	         	                						 int c2 =rs.getInt(3);
	         	                						 if(c2==1) {
	         	                						 x2  = "QUALIFIED";}
	         	                						 else { x2="NOT_QUALIFIED";}
	         	                						 int d2 =rs.getInt(4);
	         	                						 if(d2==1) {
	         	 	                						y2  = "QUALIFIED";}
	         	 	                						 else { y2="NOT_QUALIFIED";}
	         	                						 int f2 =rs.getInt(5);
	         	                						 if(f2==1) {
	         	 	                						 z2 = "QUALIFIED";}
	         	 	                						 else { z2="NOT_QUALIFIED";}
	         	                						 int g2 = rs.getInt(6);
	         	                						 if(g2==1) {
	         	 	                						 W= "QUALIFIED";}
	         	 	                						 else { W="NOT_QUALIFIED";}
	         	                						   
	         	                						 
	         	                					 listTableModel2.addRow(new Object[] { rs.getString(1),rs.getString(2),x2,y2,z2,W });
	         	                					   }
	         	                				rs.close();
	         	                			
	         	                					  
	         	                					  
	         	                				conn.close();
	         	                				
	         	                			
	         	                			} catch (SQLException e) {
	         	                				
	         	                				e.printStackTrace();}
	         	                			
	         	                			
	         	                			 JTable listTable2 = new JTable(listTableModel2);
	         	       	                 listTable2.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
	         	       	                 listTable2.setCellEditor(null);
	         	       	                 listTable2.setBounds(500, 143, 400, 183);
	         	                			
	               
	                 f2.add(new JScrollPane(listTable2));
	               //  f2.add(new JScrollPane(listTable));
	               f2.setVisible(true);
	                f2.pack();
	     
	           
	        	}  break;
	        	
	        	
	    case 3 :{ f3=new JFrame(); 
	    
  	  Object[] [] rowData3= {};
  
              Object columnNames3[]={"STUDENT_ID","COMP_ID","APT","TECH","PANEL","PROJECT","HR"};         
       	    	    DefaultTableModel listTableModel3;
       	                 listTableModel3  = new DefaultTableModel(rowData3,columnNames3);
       	                /* for(i=0;i<3;i++) {

       	                    // String rowString = "Quiz #" + i;
       	                     listTableModel.addRow(new Object[] { rowString, "ICON", "ICON" });
       	                 }*/
       	                 String query3 ="select * from MODEL3";
       	                		   
       	                			
       	                			
       	                			try {
       	                				Connection  conn=DriverManager.getConnection(dburl,us,pas);
       	                				System.out.println("Connected");
       	                			
       	                				Statement s =conn.createStatement();
       	                				
       	                				 ResultSet rs = s.executeQuery(query3);
       	                						while(rs.next()){
       	                						String a3=	rs.getString(1);
       	                						String b3=rs.getString(2);
       	                					  
       	                						 int c3 =rs.getInt(3);
       	                						 String x3;
												if(c3==1) {
       	                						 x3  = "QUALIFIED";}
       	                						 else { x3="NOT_QUALIFIED";}
       	                						 int d3 =rs.getInt(4);
       	                						 String y3;
												if(d3==1) {
       	 	                						y3 = "QUALIFIED";}
       	 	                						 else { y3="NOT_QUALIFIED";}
       	                						 int f3 =rs.getInt(5);
       	                						 String z3;
												if(f3==1) {
       	 	                						 z3 = "QUALIFIED";}
       	 	                						 else { z3="NOT_QUALIFIED";}
       	                						 int g3 = rs.getInt(6);
       	                						 String W1;
												if(g3==1) {
       	 	                						 W1= "QUALIFIED";}
       	 	                						 else { W1="NOT_QUALIFIED";}
       	                						 int g4 = rs.getInt(6);
       	                						 String W2;
												if(g4==1) {
       	 	                						 W2= "QUALIFIED";}
       	 	                						 else { W2="NOT_QUALIFIED";}
       	                						   
       	                						 
       	                					 listTableModel3.addRow(new Object[] { rs.getString(1),rs.getString(2),x3,y3,z3,W1,W2 });
       	                					   }
       	                				rs.close();
       	                			
       	                					  
       	                					  
       	                				conn.close();
       	                				
       	                			
       	                			} catch (SQLException e) {
       	                				
       	                				e.printStackTrace();}
       	                			
       	                			
       	                			 JTable listTable3 = new JTable(listTableModel3);
       	       	                 listTable3.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
       	       	                 listTable3.setCellEditor(null);
       	       	                 listTable3.setBounds(500, 143, 400, 183);
       	                			
             
               f3.add(new JScrollPane(listTable3));
             //  f2.add(new JScrollPane(listTable));
             f3.setVisible(true);
              f3.pack();
   
	    }
	    }}
	  
	public static void main(String[] args) {    
	   // new Model1();    
	}    
	}  

