
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.*;
public class PlaceModify {
	JFrame jf;
	JLabel head,val,output;
	JTextField sidtf,valtf,outputtf;
	JButton sid,cmpid,cmpnm,desg,pack,rounds,mode;
	String username ,value,column;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	public void UpdateRec(String username,String value,String column) {
		this.username = username;
		this.value=value;
		this.column=column;
		String sql="Update  INTERVIEWED_STUDENTS set "+column+"='"+value+"'"+"WHERE STUDENT_ID="+"'"+username+"'" ;
		String dburl ="jdbc:oracle:thin:@218.248.07:1521:rdbms";
		String us = "it19737016";
		String pas ="vasavi";
		try {
			Connection  conn=DriverManager.getConnection(dburl,us,pas);
			System.out.println("Connected");
			Statement s =conn.createStatement();
			int rows = s.executeUpdate(sql);
			if(rows>0) {
			outputtf.setText("UPDATED SUCCESSFULLY");
				System.out.println("Inserted Successfully");
				conn.close();
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			
			outputtf.setText("Error Occured" );
			System.out.println("Error occured");
		}}
			

	
	PlaceModify()
	{
		jf=new JFrame("MODIFY PAGE");
		head=new JLabel("ENTER STUDENT_ID:");
		sidtf=new JTextField(20);
		sid=new JButton("STUDENT ID");
		cmpid=new JButton("COMPANY ID");
		cmpnm=new JButton("COMPANY NAME");
		desg=new JButton("DESIGNATION");
		pack=new JButton("PACKAGE");
		rounds=new JButton("ROUNDS");
		mode=new JButton("MODE(ONLINE/OFFLINE)");
		val=new JLabel("ENTER THE VALUE");
		output=new JLabel("RESULT");
		valtf=new JTextField(30);
		outputtf=new JTextField(30);
		jf.getContentPane().add(head);
		jf.getContentPane().add(sidtf);
		jf.getContentPane().add(sid);
		jf.getContentPane().add(cmpid);
		jf.getContentPane().add(cmpnm);
		jf.getContentPane().add(desg);
		jf.getContentPane().add(pack);
		jf.getContentPane().add(rounds);
		jf.getContentPane().add(mode);
		jf.getContentPane().add(val);
		jf.getContentPane().add(output);
		jf.getContentPane().add(valtf);
		jf.getContentPane().add(outputtf);
		head.setBounds(631,62,200,20);
		sidtf.setBounds(631,109,200,20);
		sid.setBounds(20,50,200,20);
		cmpid.setBounds(20,80,200,20);
		cmpnm.setBounds(20,110,200,20);
		desg.setBounds(20,140,200,20);
		pack.setBounds(20,170,200,20);
		rounds.setBounds(20,200,200,20);
		mode.setBounds(20,230,200,20);
		val.setBounds(631,139,150,20);
		valtf.setBounds(631,186,200,20);
		output.setBounds(30,262,210,20);
		outputtf.setBounds(370,390,234,20);
		jf.getContentPane().setLayout(null);
		 JLabel lblNewLabel = new JLabel("");
			lblNewLabel.setBounds(-336, 6, 1471, 1490);
			ImageIcon img =new ImageIcon(this.getClass().getResource("Mdp-1.png"));
			lblNewLabel .setIcon(img);
			jf.getContentPane().add(lblNewLabel);
			
			lblNewLabel_1 = new JLabel("CLICK THE OPTION AFTER ENTERING DATA");
			lblNewLabel_1.setBounds(0, 0, 200, 40);
			jf.getContentPane().add(lblNewLabel_1);
			
			lblNewLabel_2 = new JLabel("CLICK THE OPTION AFTER ENTERING DATA");
			lblNewLabel_2.setBounds(6, 22, 292, 16);
			jf.getContentPane().add(lblNewLabel_2);
			
			lblNewLabel_3 = new JLabel("New label");
			lblNewLabel_3.setBounds(36, 22, 61, 16);
			jf.getContentPane().add(lblNewLabel_3);
			
		    jf.setSize(1000,1000);
		//jf.setSize(700,700);
		jf.setVisible(true);
		sid.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				String g=sidtf.getText();
				String s=valtf.getText();
				String n="STUDENT_ID";
				UpdateRec(g,s,n);
			}
		});
		cmpid.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				String g=sidtf.getText();
				String s=valtf.getText();
				String n="COMPANY_ID";
				UpdateRec(g,s,n);
			}
		});
		cmpnm.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				String g=sidtf.getText();
				String s=valtf.getText();
				String n="COMPANY_NAME";
				UpdateRec(g,s,n);
			}
		});
		desg.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				String g=sidtf.getText();
				String s=valtf.getText();
				String n="DESIGNATION";
				UpdateRec(g,s,n);
			}
		});
		pack.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				String g=sidtf.getText();
				String s=valtf.getText();
				String n="PACKAGE_OFF";
				UpdateRec(g,s,n);
			}
		});
		rounds.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				String g=sidtf.getText();
				String s=valtf.getText();
				String n="DESIGNATION";
				UpdateRec(g,s,n);
			}
		});
		mode.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				String g=sidtf.getText();
				String s=valtf.getText();
				String n="MODE_TEST";
				UpdateRec(g,s,n);
			}
		});
	
		
		
		
		
		
		// jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		
		
		
		
		
	}
	public static void main(String[] args)
	{
		new PlaceModify();
	}

}