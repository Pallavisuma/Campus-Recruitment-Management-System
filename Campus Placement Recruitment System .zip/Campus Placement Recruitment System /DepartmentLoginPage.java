import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.*;

public class DepartmentLoginPage extends JFrame  {
	JMenuBar mb;
	JButton submit,modify,del,insert,stud,comp,inter;
	JMenu x,submenu1,submenu2,submenu3,create,delete;
	JMenuItem m1,m2,m3,m4,m5,a1,a2,a3,a4,a5,b1,b2,b3,b4,b5,a6;
	JFrame f;
	JLabel name,id,gender,phnum,branch,email,cgpa,yearpass,password,fop;
	JTextField na,i,gen,num,bran,ema,gpa,year,output,pasw;
	String stu_name,stu_id,stu_gen,stu_num,stu_bran,stu_email,stu_cgpa,stu_yearpass,stu_pasw;
	private JMenu add;
	String v;
	private JButton btnNewButton;
	public void Vw(String v){ 
		  JFrame f1 = new JFrame("STUDENT DETAILS");
		  TextArea a =new TextArea();
		  TextArea b =new TextArea();
		  JLabel fa =new JLabel("<<<<<<<<<<STUDENTS IN DEPARTMENT>>>>>>>>>>");
		  JLabel fb =new JLabel("<<<<<<<<<<INTERVIEWED STUDENTS>>>>>>>>>>>>");
		  fa.setBounds(10,20,400,20);
		  fb.setBounds(780,20,400,20);
		  f1.getContentPane().add(a);
		  f1.getContentPane().add(fa);
		  f1.getContentPane().add(fb);
		  f1.getContentPane().add(b);
		  f1.getContentPane().setLayout(null);
		  f1.setVisible(true);
		  f1.setSize(1500,1500);
		  a.setBounds(20,100,500,800);
		  b.setBounds(700,100,500,800);
		  this.v =v;
		 String query1 ="select * from STUDENT WHERE BRANCH='"+v+"'";
		    String query2="SELECT * FROM INTERVIEWED_STUDENTS WHERE STUDENT_ID IN(SELECT STUDENT_ID FROM STUDENT WHERE BRANCH='"+v+"')";
			String dburl ="jdbc:oracle:thin:@218.248.07:1521:rdbms";
			String us = "it19737016";
			String pas ="vasavi";
			String kar=null;
			String tot ="";
			String su ="";
			String pal=null;
			try {
				Connection  conn=DriverManager.getConnection(dburl,us,pas);
				System.out.println("Connected");
			
				Statement s =conn.createStatement();
				
				 ResultSet rs = s.executeQuery(query1);
				// ResultSet rsy = s.executeQuery(query2);
				
				//;
					//System.out.println(rs);
				while(rs.next()){
					
					   kar="ID: " + rs.getString(1)
			         +"\n"+"NAME: " + rs.getString(2)+"\n"+
			           "GENDER: " + rs.getString(3)+"\n"+
			          "MOBILE_NUMBER: " + rs.getString(4)+"\n"+
			           "BRANCH: " + rs.getString(5)+"\n"+
			        " JOINING_YEAR: "+ rs.getInt(6)+"\n"+
			          "STUDENT_EMAIL " + rs.getString(7)+"\n"+
			         "CGPA: " + rs.getInt(8)+"\n"+
			          "STUD_PASSWORD: " + rs.getString(9)+"\n\n";
					 tot =tot+kar;
					   }
				a.setText(tot);
				
				rs.close();
				ResultSet rsy = s.executeQuery(query2);
				while(rsy.next()){
			  pal=     "STUDENT_ID: "+rsy.getString(1)+"\n"+
				       "INTERVIEWED_COMPANY: "+ rsy.getString(3)+"\n"+
			          "DESIGNATION_OFFERED: "+ rsy.getString(4)+"\n"+
			          "PACKAGE_OFFERED: "+rsy.getInt(5)+"\n"+
			          "ROUNDS_CLEARED: "+ rsy.getInt(6)+"\n"+
			          "INTERVIEW_MODE(ONLINE/OFFLINE): "+rsy.getString(7)+"\n\n";
				 su = su+pal;
			     
				}
				b.setText(su);
					  
					  
				conn.close();
				
			
			} catch (SQLException e) {
				
				e.printStackTrace();
				a.setText("Error Occured");
			}}
	public DepartmentLoginPage(){
		f = new JFrame("DepartmentCoordinatorLoginPage");
		mb = new JMenuBar();
		submenu1 = new JMenu("Branch");
		submenu2 = new JMenu("BRANCH_WISE_STUDENT_DETAILS");
		submenu3 = new JMenu("Branch");
		//stud =  new JButton("STUDENT_DETAILS");
		inter = new JButton("INTERVIEWD_STUDENTS");
		comp = new JButton("COMPANIES LIST");
		fop = new JLabel("<<<<VEIW OPTIONS>>>");	
		create = new JMenu("New");
		x = new JMenu("Update");
		delete =new JMenu("Delete");
		name = new JLabel("Student ID:");
		id = new JLabel("Student Name");
		gender = new JLabel("Student Gender:");
		phnum= new JLabel("Student MobileNumber:");
		branch = new JLabel("Student Branch:");
		cgpa = new JLabel("Student CGPA:");
		yearpass= new JLabel("Student Year:");
		password =new JLabel("Student Password:");
		submit =new JButton("SUBMIT");
		insert=new JButton("INSERT");
		modify=new JButton("MODIFY");
		del=new JButton("DELETE");
		pasw=new JTextField(20);
		na = new JTextField(20);
		i = new JTextField(20);
		gen= new JTextField(20);
		num = new JTextField(20);
		bran= new JTextField(20);
		ema = new JTextField(20);
		gpa= new JTextField(20);
		year = new JTextField(20);
		output =new JTextField(50);
		
		
	
		
		
		
		a1 =new JMenuItem("CSE STUDENT DETAILS");
		a2 =new JMenuItem("IT STUDENT DETAILS");
		a3 =new JMenuItem("ECE STUDENT DETAILS");
		a4 =new JMenuItem("MECHANICAL STUDENT DETAILS");
		a5 =new JMenuItem("EEE STUDENT DETAILS");
		a6=new JMenuItem("CIVIL STUDENT DETAILS");
		
	
		f.getContentPane().add(insert);
		f.getContentPane().add(modify);
		f.getContentPane().add(del);
		f.getContentPane().add(comp);
		//f.add(stud);
		f.getContentPane().add(inter);
		f.getContentPane().add(fop);
		mb.add(submenu2);
	
		
		submenu2.add(a1);
		submenu2.add(a2);
		submenu2.add(a3);
		submenu2.add(a4);
		submenu2.add(a5);
	    submenu2.add(a6);
	
	
		insert.setBounds(866,33,100,20);
		modify.setBounds(866,65,100,20);
	    del.setBounds(866,97,100,20);
	    fop.setBounds(795,129,300,20);
	   // stud.setBounds(220,250,300,20);
	    comp.setBounds(694,169,300,20);
	    inter.setBounds(694,211,300,20);

		btnNewButton = new JButton("OTHER_OPTIONS");
		btnNewButton.setForeground(UIManager.getColor("EditorPane.caretForeground"));
		btnNewButton.setBackground(UIManager.getColor("DesktopIcon.borderColor"));
		btnNewButton.setBounds(680, 261, 320, 29);
		f.getContentPane().add(btnNewButton);
	  /*  JLabel lblNewLabel = new JLabel("");
		
		  f.getContentPane().add(lblNewLabel);
		  ImageIcon img =new ImageIcon(this.getClass().getResource("dp-1.png"));
	     lblNewLabel .setIcon(img);*/
	    JLabel lblNewLabel = new JLabel("");
	    lblNewLabel.setBounds(-300, -10, 20971, 1450);
	    ImageIcon img =new ImageIcon(this.getClass().getResource("dp-1.png"));
		f.getContentPane().add(lblNewLabel);
		lblNewLabel .setIcon(img);
	//	f.setVisible(true);
		f.getContentPane().setLayout(null);
		f.setVisible(true);
	    insert.addActionListener(new ActionListener(){

			@SuppressWarnings("deprecation")
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new DepInsertModify();	
				}
			});
	   modify.addActionListener(new ActionListener(){

			@SuppressWarnings("deprecation")
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new DepModifyButton();
				}
			});
	   del.addActionListener(new ActionListener(){

			@SuppressWarnings("deprecation")
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new DepDelete();
				}
			});
		f.setJMenuBar(mb);
		f.setSize(1000,1000);
		f.getContentPane().setLayout(null);
		
		
		
		
		btnNewButton.addActionListener(new ActionListener(){

			@SuppressWarnings("deprecation")
			@Override
			public void actionPerformed(ActionEvent arg0) {
			new	OtherOptions();  
			}
			});
	


		a1.addActionListener(new ActionListener(){

			@SuppressWarnings("deprecation")
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				 Vw("CSE");  
					  
			}
			});
		a2.addActionListener(new ActionListener(){

				@SuppressWarnings("deprecation")
				@Override
				public void actionPerformed(ActionEvent arg0) {
					 Vw("IT");  
				}
				});a3.addActionListener(new ActionListener(){

					@SuppressWarnings("deprecation")
					@Override
					public void actionPerformed(ActionEvent arg0) {
						 Vw("ECE");  
						
					}
					});
				a4.addActionListener(new ActionListener(){

						@SuppressWarnings("deprecation")
						@Override
						public void actionPerformed(ActionEvent arg0) {
							 Vw("MECHANICAL");  
							
						}
						});
				a5.addActionListener(new ActionListener(){

							@SuppressWarnings("deprecation")
							@Override
							public void actionPerformed(ActionEvent arg0) {
								 Vw("EEE");  
								
							}
							});
				a6.addActionListener(new ActionListener(){

					@SuppressWarnings("deprecation")
					@Override
					public void actionPerformed(ActionEvent arg0) {
						 Vw("CIVIL");  
					}
					});
		
				
		comp.addActionListener(new ActionListener(){

			@SuppressWarnings("deprecation")
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new	StudentMainPage(2);
			}
			});
		inter.addActionListener(new ActionListener(){

			@SuppressWarnings("deprecation")
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new	StudentMainPage(1);
			}
			});
		// f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);	
	}
		
		
		
		
		
	
	public static void main(String[] args) {
		new DepartmentLoginPage();
	}
}
