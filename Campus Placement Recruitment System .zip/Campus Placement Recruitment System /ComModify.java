import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.*;
import java.awt.Color;

public class ComModify{
JFrame f ;
JButton stu_name,stu_id,stu_gen,stu_num,stu_bran,stu_email,stu_cgpa,stu_yearpass,stu_pasw,submit;
JLabel op,sid,val;
JTextField  fsid,fval,res;
String username ,value,column;
private JLabel lblNewLabel;
private JLabel lblNewLabel_1;
public void UpdateRec(String username,String value,String column) {
	this.username = username;
	this.value=value;
	this.column=column;
	String sql="Update COMPANY set "+column+"='"+value+"'"+"WHERE COMP_ID="+"'"+username+"'" ;
	String dburl ="jdbc:oracle:thin:@218.248.07:1521:rdbms";
	String us = "it19737016";
	String pas ="vasavi";
	try {
		Connection  conn=DriverManager.getConnection(dburl,us,pas);
		System.out.println("Connected");
		Statement s =conn.createStatement();
		int rows = s.executeUpdate(sql);
		if(rows>0) {
		res.setText("UPDATED SUCCESSFULLY");
			System.out.println("Inserted Successfully");
			conn.close();
			
		}
	} catch (SQLException e) {
		e.printStackTrace();
		
		res.setText("Error Occured" );
		System.out.println("Error occured");
	}}
		


public ComModify(){
	f = new JFrame("Update Options");
	op = new JLabel("<SELECT THE OPTIONS TO BE UPDATED AFTER ENTERING DATA>");
	op.setForeground(Color.WHITE);
	sid =new JLabel("ENTER COMPANY ID(TO MODIFY):");
	sid.setForeground(Color.WHITE);
	val = new JLabel("ENTER VALUE TO BE SET:");
	val.setForeground(Color.WHITE);
	fsid = new JTextField(40);
	fval = new JTextField(40);
	//submit= new JButton("SUBMIT");
	res=new JTextField(40);
	stu_name =new JButton("COMPANY NAME");
	stu_name.setForeground(Color.BLACK);
	stu_id  =new JButton("COMPANY ID");
	stu_id.setForeground(Color.BLACK);
	stu_gen =new JButton("COMPANY WEBSITE");
	stu_num =new JButton("COMPANY CONTACTINFO");
	stu_bran =new JButton("DATE OF VISIT");
	stu_bran.setBackground(new Color(238, 238, 238));
	
	f.getContentPane().add(stu_name);
	f.getContentPane().add(stu_id);
    f.getContentPane().add(stu_gen);
    f.getContentPane().add(stu_num);
    f.getContentPane().add(stu_bran);
   
    f.getContentPane().add(op);
    f.getContentPane().add(sid);
    f.getContentPane().add(fsid);
    f.getContentPane().add(val);
    f.getContentPane().add(fval);
    //f.add(submit);
    f.getContentPane().add(res);
    op.setBounds(0,22,500,20);
   // submit.setBounds(400,350,150,20);
    sid.setBounds(610,70,300,20);
    val.setBounds(610,150,300,20);
    fval.setBounds(610,194,290,20);
    fsid.setBounds(610,100,300,20);
    stu_name .setBounds(26,71,272,20);
    stu_id.setBounds(26,103,272,20);
    stu_gen.setBounds(26,135,272,20);
    stu_num.setBounds(26,170,272,20);
    stu_bran.setBounds(26,202,272,20);
 

//	
	
    res.setBounds(196,473,500,45);
    f.setSize(910,1000);
	f.getContentPane().setLayout(null);
	
	lblNewLabel = new JLabel("");
	lblNewLabel.setBounds(-353, 0, 1471, 1490);
	ImageIcon img =new ImageIcon(this.getClass().getResource("Mdp-1.png"));
	lblNewLabel .setIcon(img);
	f.getContentPane().add(lblNewLabel);
	
	
	f.setVisible(true);
	stu_name.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			String g=fsid.getText();
			String s=fval.getText();
			String n="COMPANY_NAME";
			UpdateRec(g,s,n);
		}
	});
		
	stu_id.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			String g=fsid.getText();
			String s=fval.getText();
			String n="COMPANY_ID";
			UpdateRec(g,s,n);
		}
	});
		
	stu_gen.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			String g=fsid.getText();
			String s=fval.getText();
			String n="WEBSITE";
			UpdateRec(g,s,n);
		}
	});
		
	  stu_num.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			String g=fsid.getText();
			String s=fval.getText();
			String n="CONTACTINFO";
			UpdateRec(g,s,n);
		}
	});
		
	/*  stu_email.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			String g=fsid.getText();
			String s=fval.getText();
			String n="STUDENT_EMAILID";
			UpdateRec(g,s,n);
		}
	});*/
		
	/*  stu_cgpa.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			String g=fsid.getText();
			String s=fval.getText();
			String n="CGPA";
			UpdateRec(g,s,n);
		}
	});
	  stu_yearpass.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			String g=fsid.getText();
			String s=fval.getText();
			String n="JOINING_YEAR";
			UpdateRec(g,s,n);
		}
	});
	  stu_pasw.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			String g=fsid.getText();
			String s=fval.getText();
			String n="STUD_PASSWORD";
			UpdateRec(g,s,n);
		}
	});*/
	  stu_bran.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			String g=fsid.getText();
			String s=fval.getText();
			String n="VISIT_DATE";
			UpdateRec(g,s,n);
		}
	});
	 // f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		
}
public static void main(String[] args) {
	new ComModify();
}

}
