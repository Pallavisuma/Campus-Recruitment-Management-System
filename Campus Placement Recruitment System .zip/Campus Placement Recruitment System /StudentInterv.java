import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.*;

public class StudentInterv {
	JTextField  fstud_id,fcom_id,fcom_name,fdesignation,foffpack,frounds,fmode,output;
	JLabel stud_id,com_id,com_name,designation,offpack,rounds,mode,model;
	JButton submit;
	JFrame f;
	JMenuBar mb;
	JMenu delete;
	JMenu x,submenu1,submenu2,submenu3,create;
	JMenuItem m1,m2,m3,m4,m5,a1,a2,a3,a4,a5,b1,b2,b3,b4,b5;
	JButton r1,r2,r3;
	int  aptitude;
	int technical;
	int hrr;
	int res;
	int panel;
	int proj;
	JTextArea ta;
	//ButtonGroup bg;
	
	public void Insert(String query)
	{
		String dburl ="jdbc:oracle:thin:@218.248.07:1521:rdbms";
		String us = "it19737016";
		String pas ="vasavi";
		try {
			Connection  conn=DriverManager.getConnection(dburl,us,pas);
			System.out.println("Connected");
			String sql ="INSERT INTO Sailors(sid,sname,rating,age)"
					    +"VALUES('200','ala',3,1.5)";
			Statement s =conn.createStatement();
			int rows = s.executeUpdate(query);
			conn.close();
			if(rows>0) {
			output.setText("Inserted Successfully");
				System.out.println("Inserted Successfully");
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
			output.setText("Error Occured");
		}}
	public void InsertModel1(String query)
	{
		String dburl ="jdbc:oracle:thin:@218.248.07:1521:rdbms";
		String us = "it19737016";
		String pas ="vasavi";
		try {
			Connection  conn=DriverManager.getConnection(dburl,us,pas);
			System.out.println("Connected");
			String sql ="INSERT INTO Sailors(sid,sname,rating,age)"
					    +"VALUES('200','ala',3,1.5)";
			Statement s =conn.createStatement();
			int rows = s.executeUpdate(query);
			conn.close();
			if(rows>0) {
			output.setText("Inserted Successfully");
				System.out.println("Inserted Successfully");
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
			output.setText("Error Occured");
		}}
	
	public StudentInterv(){
		
		f = new JFrame("Interviwed Students Form");
		mb = new JMenuBar();
		submenu1 = new JMenu("Branch");
		submenu2 = new JMenu("Branch");
		submenu3 = new JMenu("Branch");
		create = new JMenu("New");
		x = new JMenu("Update");
		delete =new JMenu("Delete");
		submit =new JButton("Submit");
		fstud_id =new JTextField(20);
		fcom_id =new JTextField(20);
		fcom_name=new JTextField(20);
		fdesignation=new JTextField(20);
		foffpack=new JTextField(20);
		frounds=new JTextField(20);
		fmode=new JTextField(20);
		stud_id=new JLabel("Student RollNumber:");
		com_id=new JLabel("Company ID:");
		com_name=new JLabel("Company Name:");
		designation= new JLabel("Designation:");
		offpack=new JLabel("Package:");
		rounds=new JLabel("Rounds Cleared");
		mode=new JLabel("Online/Offline");
        output = new JTextField(30);
		a1 =new JMenuItem("Cse");
		a2 =new JMenuItem("It");
		a3 =new JMenuItem("Ece");
		a4 =new JMenuItem("Mech");
		a5 =new JMenuItem("EEE");
		b1 =new JMenuItem("Cse");
		b2 =new JMenuItem("It");
		b3 =new JMenuItem("Ece");
		b4 =new JMenuItem("Mech");
		b5 =new JMenuItem("EEE");
		m1 =new JMenuItem("Cse");
		m2 =new JMenuItem("It");
		m3 =new JMenuItem("Ece");
		m4 =new JMenuItem("Mech");
		m5 =new JMenuItem("EEE");
		model=new JLabel("Model");
		//modeltf=new JTextField(20);
		r1=new JButton("MODEL-1");
		r2=new JButton("MODEL-2");
		r3=new JButton("MODEL-3");
		//bg=new ButtonGroup();
		//bg.add(r1);
		//bg.add(r2);
		//bg.add(r3);
		
		x.add(submenu1);
		create.add(submenu2);
		delete.add(submenu3);
		submenu1.add(m1);
		submenu1.add(m2);
		submenu1.add(m3);
		submenu1.add(m4);
		submenu1.add(m5);
		submenu2.add(a1);
		submenu2.add(a2);
		submenu2.add(a3);
		submenu2.add(a4);
		submenu2.add(a5);
		submenu3.add(b1);
		submenu3.add(b2);
		submenu3.add(b3);
		submenu3.add(b4);
		submenu3.add(b5);
		mb.add(create);
		mb.add(x);
	    mb.add(delete);
		f.add(stud_id);
		f.add(com_id);
		f.add(com_name);
		f.add(designation);
		f.add(offpack);
		f.add(rounds);
		f.add(mode);
		f.add(fstud_id);
		f.add(fcom_id);
		f.add(fcom_name);
		f.add(fdesignation);
		f.add(foffpack);
		f.add(frounds);
		f.add(fmode);
		f.add(submit);
		f.add(output);
		f.add(model);
		f.add(r1);
		f.add(r2);
		f.add(r3);
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(0,0, 1300, 980);
		ImageIcon img =new ImageIcon(this.getClass().getResource("InsertP-1.png"));
		lblNewLabel .setIcon(img);
		f.getContentPane().add(lblNewLabel);
		//f.add(modeltf);
		
		stud_id.setBounds(20,50,200,20);
		com_id.setBounds(20,100,200,20);
		com_name.setBounds(20,150,200,20);
		designation.setBounds(20,200,100,20);
		offpack.setBounds(20,250,100,20);
		rounds.setBounds(20,300,200,20);
		mode.setBounds(20,350,200,20);
		fstud_id.setBounds(200,50,200,20);
		fcom_id.setBounds(200,100,200,20);
		fcom_name.setBounds(200,150,200,20);
		fdesignation.setBounds(200,200,200,20);
		foffpack.setBounds(200,250,200,20);
		frounds.setBounds(200,300,200,20);
		fmode.setBounds(200,350,200,20);
		model.setBounds(20,400,200,20);
		r1.setBounds(200,400,100,30);
		r2.setBounds(300,400,100,30);
		r3.setBounds(400,400,100,30);
		submit.setBounds(150,450,200,20);
		output.setBounds(100,500,300,30);
	
		f.setSize(800,800);
		f.setJMenuBar(mb);
		
		f.setLayout(null);
		f.setVisible(true);
		
		
	
	submit.addActionListener(new ActionListener(){

		//@SuppressWarnings("deprecation")
		//@Override
		public void actionPerformed(ActionEvent arg0) {
	
		String a=	fstud_id.getText(); 
		String b=	fcom_id.getText();
		String c=	fcom_name.getText();
		String d=	fdesignation.getText();
		String e=	foffpack.getText();
		String fl=	frounds.getText();
		String g=	fmode.getText();	
				
			String query="INSERT INTO INTERVIEWED_STUDENTS VALUES("+"'"+a+"'"+",'"+b+"',"+"'"+c+"',"+"'"+d+"',"+"'"+e+"',"+"'"+fl+"',"+"'"+g+"'"+")";
			Insert(query);
			
			
			
		   
		}
		});// f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	r1.addActionListener(new ActionListener(){

		//@SuppressWarnings("deprecation")
		//@Override
		public void actionPerformed(ActionEvent arg0) {
			System.out.println("karthka");
			JFrame jg=new JFrame("MODEL-1");
			JLabel ml=new JLabel("SELECT EITHER YES OR NO:");
			JLabel mla=new JLabel("APTITUDE");
			JRadioButton b1=new JRadioButton("YES");
			JRadioButton b2=new JRadioButton("NO");
			ButtonGroup bg=new ButtonGroup();
			bg.add(b1);
			bg.add(b2);
			JLabel mlt=new JLabel("TECHNICAL");
			JRadioButton t1=new JRadioButton("YES");
			JRadioButton t2=new JRadioButton("NO");
			ButtonGroup bt=new ButtonGroup();
			bt.add(t1);
			bt.add(t2);
			JLabel mlh=new JLabel("HR ROUND");
			JRadioButton h1=new JRadioButton("YES");
			JRadioButton h2=new JRadioButton("NO");
			ButtonGroup bh=new ButtonGroup();
			bh.add(h1);
			bh.add(h2);
			ta=new JTextArea();
			JButton lr=new JButton("SUBMIT");
			
			ml.setBounds(20,20,200,20);
			mla.setBounds(20,80,100,20);
			b1.setBounds(130,80,100,20);
			b2.setBounds(250,80,100,20);
			mlt.setBounds(20,100,100,20);
			t1.setBounds(130,100,100,20);
			t2.setBounds(250,100,100,20);
			mlh.setBounds(20,120,100,20);
			h1.setBounds(130,120,100,20);
			h2.setBounds(250,120,100,20);
			ta.setBounds(100,300,300,300);
			lr.setBounds(100,200,100,20);
			jg.add(ml);
			jg.add(b1);
			jg.add(b2);
			jg.add(mla);
			jg.add(t1);
			jg.add(t2);
			jg.add(mlt);
			jg.add(h1);
			jg.add(h2);
			jg.add(mlh);
			jg.setSize(800,800);
			jg.setLayout(null);
			jg.setVisible(true);
			jg.add(lr);
			jg.add(ta);
			//String aptitude="";
			/*String technical="" ;
			String hrr="";
			String res="";*/
			System.out.println(b1.isSelected());
			b1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					aptitude=1;
				}
			});
			b2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					aptitude=0;
				}
			});
			t1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					technical=1;
				}
			});
			t2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					technical=0;
				}
			});
			h1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
						hrr=1;
				}
			});
			h2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					hrr=0;
				}
			});
			lr.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					//res="APTITUDE:"+aptitude+"\n"+"TECHNICAL"+technical+"\n"+"HR ROUND"+hrr+"\n";
					String a=	fstud_id.getText(); 
					String b=	fcom_id.getText();
					String query="INSERT INTO MODEL1 VALUES('"+a+"'"+","+"'"+b+"'"+","+aptitude+","+technical+","+hrr+")";
					InsertModel1( query);
					//ta.setText(res);
					
					//ta.setText(res);
				}
			});
			/*String query="INSERT INTO MODEL1 VALUES("+aptitude+","+technical+","+hrr+")";
			InsertModel1( query);
			
			System.out.println("*"+aptitude);*/
			
		}});
	r2.addActionListener(new ActionListener(){

		//@SuppressWarnings("deprecation")
		//@Override
		public void actionPerformed(ActionEvent arg0) {
			System.out.println("karthka");
			JFrame jg=new JFrame("MODEL-1");
			JLabel ml=new JLabel("SELECT EITHER YES OR NO:");
			JLabel mla=new JLabel("APTITUDE");
			JRadioButton b1=new JRadioButton("YES");
			JRadioButton b2=new JRadioButton("NO");
			ButtonGroup bg=new ButtonGroup();
			bg.add(b1);
			bg.add(b2);
			JLabel mlt=new JLabel("TECHNICAL");
			JRadioButton t1=new JRadioButton("YES");
			JRadioButton t2=new JRadioButton("NO");
			ButtonGroup bt=new ButtonGroup();
			bt.add(t1);
			bt.add(t2);
			JLabel mlp=new JLabel("PANEL INTERVIEW");
			JRadioButton p1=new JRadioButton("YES");
			JRadioButton p2=new JRadioButton("NO");
			ButtonGroup bp=new ButtonGroup();
			bp.add(p1);
			bp.add(p2);
			JLabel mlh=new JLabel("HR ROUND");
			JRadioButton h1=new JRadioButton("YES");
			JRadioButton h2=new JRadioButton("NO");
			ButtonGroup bh=new ButtonGroup();
			bh.add(h1);
			bh.add(h2);
			
			ta=new JTextArea();
			JButton lr=new JButton("SUBMIT");
			
			ml.setBounds(20,20,200,20);
			mla.setBounds(20,80,100,20);
			b1.setBounds(130,80,100,20);
			b2.setBounds(250,80,100,20);
			mlt.setBounds(20,100,100,20);
			t1.setBounds(130,100,100,20);
			t2.setBounds(250,100,100,20);
			mlp.setBounds(20,120,150,20);
			p1.setBounds(130,120,100,20);
			p2.setBounds(250,120,100,20);
			mlh.setBounds(20,140,100,20);
			h1.setBounds(130,140,100,20);
			h2.setBounds(250,140,100,20);
			ta.setBounds(100,300,300,300);
			lr.setBounds(100,200,100,20);
			jg.add(ml);
			jg.add(b1);
			jg.add(b2);
			jg.add(mla);
			jg.add(t1);
			jg.add(t2);
			jg.add(mlt);
			jg.add(h1);
			jg.add(h2);
			jg.add(mlh);
			jg.add(p1);
			jg.add(p2);
			jg.add(mlp);
			jg.setSize(800,800);
			jg.setLayout(null);
			jg.setVisible(true);
			jg.add(lr);
			jg.add(ta);
			//String aptitude="";
			/*String technical="" ;
			String hrr="";
			String res="";*/
			System.out.println(b1.isSelected());
			b1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					aptitude=1;
				}
			});
			b2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					aptitude=0;
				}
			});
			t1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					technical=1;
				}
			});
			t2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					technical=0;
				}
			});
			p1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					panel=1;
				}
			});
			p2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					panel=0;
				}
			});
			h1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
						hrr=1;
				}
			});
			h2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					hrr=0;
				}
			});
			lr.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					//res="APTITUDE:"+aptitude+"\n"+"TECHNICAL"+technical+"\n"+"PANEL INTERVIEW"+panel+"\n"+"HR ROUND"+hrr+"\n";
					//ta.setText(res);
					
					//ta.setText(res);
					String a=	fstud_id.getText(); 
					String b=	fcom_id.getText();
					String query="INSERT INTO MODEL2 VALUES('"+a+"'"+","+"'"+b+"'"+","+aptitude+","+technical+","+panel+","+hrr+")";
					InsertModel1( query);
				}
			});
			
			System.out.println("**"+aptitude);
			
		}});
	r3.addActionListener(new ActionListener(){

		//@SuppressWarnings("deprecation")
		//@Override
		public void actionPerformed(ActionEvent arg0) {
			System.out.println("karthka");
			JFrame jg=new JFrame("MODEL-1");
			JLabel ml=new JLabel("SELECT EITHER YES OR NO:");
			JLabel mla=new JLabel("APTITUDE");
			JRadioButton b1=new JRadioButton("YES");
			JRadioButton b2=new JRadioButton("NO");
			ButtonGroup bg=new ButtonGroup();
			bg.add(b1);
			bg.add(b2);
			JLabel mlt=new JLabel("TECHNICAL");
			JRadioButton t1=new JRadioButton("YES");
			JRadioButton t2=new JRadioButton("NO");
			ButtonGroup bt=new ButtonGroup();
			bt.add(t1);
			bt.add(t2);
			JLabel mlp=new JLabel("PANEL INTERVIEW");
			JRadioButton p1=new JRadioButton("YES");
			JRadioButton p2=new JRadioButton("NO");
			ButtonGroup bp=new ButtonGroup();
			bp.add(p1);
			bp.add(p2);
			JLabel mlk=new JLabel("PROJECT");
			JRadioButton k1=new JRadioButton("YES");
			JRadioButton k2=new JRadioButton("NO");
			ButtonGroup bk=new ButtonGroup();
			bk.add(k1);
			bk.add(k2);
			JLabel mlh=new JLabel("HR ROUND");
			JRadioButton h1=new JRadioButton("YES");
			JRadioButton h2=new JRadioButton("NO");
			ButtonGroup bh=new ButtonGroup();
			bh.add(h1);
			bh.add(h2);
			
			ta=new JTextArea();
			JButton lr=new JButton("SUBMIT");
			
			ml.setBounds(20,20,200,20);
			mla.setBounds(20,80,100,20);
			b1.setBounds(130,80,100,20);
			b2.setBounds(250,80,100,20);
			mlt.setBounds(20,100,100,20);
			t1.setBounds(130,100,100,20);
			t2.setBounds(250,100,100,20);
			mlp.setBounds(20,120,150,20);
			p1.setBounds(130,120,100,20);
			p2.setBounds(250,120,100,20);
			mlk.setBounds(20,140,100,20);
			k1.setBounds(130,140,100,20);
			k2.setBounds(250,140,100,20);
			mlh.setBounds(20,160,100,20);
			h1.setBounds(130,160,100,20);
			h2.setBounds(250,160,100,20);
			ta.setBounds(100,300,300,300);
			lr.setBounds(100,200,100,20);
			jg.add(ml);
			jg.add(b1);
			jg.add(b2);
			jg.add(mla);
			jg.add(t1);
			jg.add(t2);
			jg.add(mlt);
			jg.add(h1);
			jg.add(h2);
			jg.add(k1);
			jg.add(k2);
			jg.add(mlk);
			jg.add(mlh);
			jg.add(p1);
			jg.add(p2);
			jg.add(mlp);
			
			jg.setSize(800,800);
			jg.setLayout(null);
			jg.setVisible(true);
			jg.add(lr);
			jg.add(ta);
			//String aptitude="";
			/*String technical="" ;
			String hrr="";
			String res="";*/
			System.out.println(b1.isSelected());
			b1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					aptitude=1;
				}
			});
			b2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					aptitude=0;
				}
			});
			t1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					technical=1;
				}
			});
			t2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					technical=0;
				}
			});
			p1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					panel=1;
				}
			});
			p2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					panel=0;
				}
			});
			k1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					proj=1;
				}
			});
			k2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					proj=0;
				}
			});
			
			h1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
						hrr=1;
				}
			});
			h2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					hrr=0;
				}
			});
			lr.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String a=	fstud_id.getText(); 
					String b=	fcom_id.getText();
					String query="INSERT INTO MODEL3 VALUES('"+a+"'"+","+"'"+b+"'"+","+aptitude+","+technical+","+panel+","+proj+","+hrr+")";
					InsertModel1( query);
					
					//ta.setText(res);
				}
			});
			
			System.out.println("**"+aptitude);
			
		}});
	
	}
	
		public static void main(String[] args) {
			new StudentInterv();
		}
		
		
		
		
	}